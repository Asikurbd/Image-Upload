<?php
require_once 'auth.php';
redirect_if_not_logged_in();

// Load existing students
$students = [];
if (file_exists('students.json')) 

{
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Generate new ID
    $newId = 1;
    if (!empty($students)) {
        $lastStudent = end($students);
        $newId = $lastStudent['id'] + 1;
    }
    
    // Add new student
    $students[] = [
        'id' => $newId,
        'roll' => $_POST['roll'],
        'class' => $_POST['class'],
		'bio_id' => $_POST['bio_id'],
		'group' => $_POST['group'],
        'section' => $_POST['section'],
        'name_bangla' => $_POST['name_bangla'],
        'name_english' => $_POST['name_english'],
        'dob' => $_POST['dob'],
        'birth_certificate' => $_POST['birth_certificate'],
        'mobile' => $_POST['mobile'],
        'gender' => $_POST['gender'],
        'blood_group' => $_POST['blood_group'],
        'father_name_bangla' => $_POST['father_name_bangla'],
        'father_name_english' => $_POST['father_name_english'],
        'father_dob' => $_POST['father_dob'],
        'father_nid' => $_POST['father_nid'],
        'mother_name_bangla' => $_POST['mother_name_bangla'],
        'mother_name_english' => $_POST['mother_name_english'],
        'mother_dob' => $_POST['mother_dob'],
        'mother_nid' => $_POST['mother_nid'],
		'present_address' => $_POST['present_address'],
		'permanent_paddress' => $_POST['permanent_paddress'],
		'photo' => $_POST['photo'],
		'sign' => $_POST['sign'],
		'rel' => $_POST['rel'],
    ];
    
    // Save to file
    file_put_contents('students.json', json_encode($students));
    
    // Redirect to list
    header('Location: index.php');
    exit;
}
?>



<head>
  	<meta charset="utf-8" />
   	<title>Add Student</title>
  	<link rel="stylesheet" href="style.css" />
  	<link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>

<html>
  

<form method="post">
                
<table width='100%' border='1'>
 
<tr>
<td> 

Serial

</td> <td align='center' width='5%'>:</td>
<td> 

 <input type="text" name="roll" required>
 
<td align='center'><b>Photo</b></td>
</td></tr>

<tr>

<td width='25%'> Class </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<select name="class" Type="text" required>
    <option value="">Select</option>
	<option value="Junior-One">Junior One</option>
	<option value="Nursery">Nursery</option>
    <option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
    <option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
    <option value="9">9</option>
    <option value="Ten">10</option>
</select>

</td>

<td rowspan='7' align='center'><b>ছবি</b> এবং <b>স্বাক্ষর</b> এর লিংক কপি পেস্ট। <br>
<b> ছবি </b>
 
<input id='photo' name='photo' type='text' style='width: 150px;'>

<b> স্বাক্ষর</b>
  
<input id='sign' name='sign' type='text' style='width: 150px;'>

<a href='demo-picture.html' target='_blank'> Demo</a>
</td>
</tr>

<tr><td> Section </td> 
<td align='center' width='5%'>:</td>
<td width='48%'> 

<select name="section">
<option value="Red">Red</option>
<option value="Green">Green</option>
</select>

</td>
</tr>

<tr><td width='15%'> Full Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" name="name_english" required>

</td>
</tr>

<tr><td width='15%'> সম্পূর্ণ নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" name="name_bangla" required>

</td>
</tr>

<tr><td width='15%'> Date Of Birth </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" name="dob">

</td>
</tr>

<tr><td width='15%'> Birth Certificate No </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" name="birth_certificate">

</td>
</tr>

<tr><td width='15%'> Mobile Number </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

 <input type="text" name="mobile" required>

</td>
</tr>


<tr><td width='15%'> Student ID</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" name="bio_id" required>

</td></tr>

<tr><td width='15%'> Group</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="group">
<option value="N/A">N/A</option>
<option value="Science+H.M">Science+H.M</option>
<option value="Science+Agri">Science+Agri</option>
<option value="Arts+Agri">Arts+Agri</option>
<option value="Commerce">Commerce</option>
</select>

</td></tr>

<tr><td width='15%'> Gender </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="gender">
<option value="*Male">*Male</option>
 <option value="Female">Female</option>
 </select>

</td>
</tr>

<tr><td width='15%'> Blood Group </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="blood_group">
<option value="N/A">N/A</option>
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
</select>

</td>
</tr>

<tr><td width='15%' calspan='2'> ধর্ম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  <select name="rel">
<option value="">Select</option>
<option value="ইসলাম ধর্ম">ইসলাম ধর্ম</option>
<option value="হিন্দু ধর্ম">হিন্দু ধর্ম</option>
<option value="বৌদ্ধ ধর্ম">বৌদ্ধ ধর্ম</option>
<option value="খৃস্টান ধর্ম">খৃস্টান ধর্ম</option>
<option value="অন্যান্য">অন্যান্য</option>
</select> 
  
</td>
</tr>

<tr><td width='15%'> বর্তমান ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text2" name="present_address">

</td>
</tr>

<tr><td width='15%'> স্থায়ী ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text2" name="permanent_paddress">

</td>
</tr>

<tr><td width='15%'> Father's Name (English)</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" name="father_name_english" required>

</td>
</tr>

<tr><td width='15%'> পিতার নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" name="father_name_bangla" required>

</td>
</tr>

<tr><td width='15%'> Father's Date of Birth</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
 <input type="text" name="father_dob">
  
</td>
</tr>

<tr><td width='15%'>Father's NID No </td> <td align='center' width='5%'>:</td>
<td colspan='3'> 

<input type="text" name="father_nid">

</td>
</tr>

<tr><td width='15%'>Mother's Name (English)</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" name="mother_name_english" required>

</td>
</tr>

<tr><td width='15%'> মাতার নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" name="mother_name_bangla" required>

</td>
</tr>

<tr><td width='15%'> Mother's Date of Birth </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" name="mother_dob">

</td>
</tr>

<!-- copy this table -->

<tr><td width='15%'> Mother's NID No </td> <td align='center' width='5%'>:</td><td colspan='2'>  
 
<input type="text" name="mother_nid"> 

</td></tr>  
<!-- copy end this table -->
   

</table>
 
    
<center> <input type="submit" value="Submit" /> </center>
                 
</form>
</html>

