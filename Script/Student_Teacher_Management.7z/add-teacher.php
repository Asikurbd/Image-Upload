<?php

date_default_timezone_set('Asia/Dhaka');
$currentDateTime = date('d-m-Y h:i:s A');

// Load existing teacher
$teacher = [];
if (file_exists('teachers.json')) 

{
    $teacher = json_decode(file_get_contents('teachers.json'), true) ?: [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Generate new ID
    $newId = 1;
    if (!empty($teacher)) {
        $lastStudent = end($teacher);
        $newId = $lastStudent['id'] + 1;
    }
    
    // Add new student
    $teacher[] = [
        'id' => $newId,
		
        'post' => $_POST['post'],
        'name' => $_POST['name'],
		'ename' => $_POST['ename'],
		'fname' => $_POST['fname'],
		'fename' => $_POST['fename'],
		'mname' => $_POST['mname'],
		'mename' => $_POST['mename'],
		'dob' => $_POST['dob'],
		'pob' => $_POST['pob'],
		'gen' => $_POST['gen'],
		'nat' => $_POST['nat'],
		'brn' => $_POST['brn'],
		'nid' => $_POST['nid'],
		'pid' => $_POST['pid'],
		'rel' => $_POST['rel'],
		'pad' => $_POST['pad'],
		'pead' => $_POST['pead'],
		'mob' => $_POST['mob'],
		'email' => $_POST['email'],
		'mar' => $_POST['mar'],
		'xm' => $_POST['xm'],
		'res' => $_POST['res'],
		'brd' => $_POST['brd'],
		'grp' => $_POST['grp'],
		'rl' => $_POST['rl'],
		'py' => $_POST['py'],
		'att' => $_POST['att'],
		'pp' => $_POST['pp'],
		'blood' => $_POST['blood'],
		'xm2' => $_POST['xm2'],
		'res2' => $_POST['res2'],
		'brd2' => $_POST['brd2'],
		'grp2' => $_POST['grp2'],
		'rl2' => $_POST['rl2'],
		'py2' => $_POST['py2'],
		'xm3' => $_POST['xm3'],
		'res3' => $_POST['res3'],
		'sub' => $_POST['sub'],
		'crs' => $_POST['crs'],
		'uni' => $_POST['uni'],
		'py3' => $_POST['py3'],
		'xm4' => $_POST['xm4'],
		'res4' => $_POST['res4'],
		'sub2' => $_POST['sub2'],
		'crs2' => $_POST['crs2'],
		'uni2' => $_POST['uni2'],
		'py4' => $_POST['py4'],
		'photo' => $_POST['photo'],
		'sign' => $_POST['sign'],
		'bisoy' => $_POST['bisoy'],
		'husb' => $_POST['husb'],
		'huse' => $_POST['huse'],
		'hbirth' => $_POST['hbirth'],
		'hnid' => $_POST['hnid'],
		'hwork' => $_POST['hwork'],
		'fbirth' => $_POST['fbirth'],
		'fdead' => $_POST['fdead'],
		'fnid' => $_POST['fnid'],
		'fwork' => $_POST['fwork'],
		'mbirth' => $_POST['mbirth'],
		'mdead' => $_POST['mdead'],
		'mnid' => $_POST['mnid'],
		'mwork' => $_POST['mwork'],
		'cnam' => $_POST['cnam'],
		'cname' => $_POST['cname'],
		'cbirth' => $_POST['cbirth'],
		'cnid' => $_POST['cnid'],
		'cwork' => $_POST['cwork'],
		'rg1' => $_POST['rg1'],
		'rg2' => $_POST['rg2'],
		'rg3' => $_POST['rg3'],
		'rg4' => $_POST['rg4'],
		'#' => $_POST['#'],
		'#' => $_POST['#'],
		
		

    ];
    
    // Save to file
    file_put_contents('teachers.json', json_encode($teacher));
    
    // Redirect to list
    header('Location: success.php');
    exit;
}
?>



<head>
  	<meta charset="utf-8" />
   	<title>Add Teachers</title>
  	<link rel="stylesheet" href="style.css" />
  	<link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>

<html>
  
 <center><a href=''><ar2> Information Database </ar2></a><br></center> 
  
<center> <font color='red'> নিচের তথ্যগুলো অবশ্যই সঠিকভাবে পূরণ করবেন। </font> <br> বাংলা অপশনের যাইগায় বাংলায় তথ্য পূরণ করবেন এবং English অপশনের যাইগায় English এ পূরণ
   করবেন। <br> তবে জন্ম তারিখ, জন্মনিবন্ধন নম্বর, NID নম্বর, মোবাইল নম্বর, প্রথম যোগদানের তারিখ, এগুলা অবশ্যই English এ পূরণ করবেন।<br> 
   education qualification গুলি অবশ্যই English এ পূরণ করবেন। </center><br>  
  

<form method="post">
                
<table width='100%' border='1'>
 
<tr>
<td> পদবী </td> <td align='center' width='5%'>:</td>
<td> 
  
<select name="post" required>
<option value="">নির্বাচন করুন...</option>
<option value="সহকারী শিক্ষক">সহকারী শিক্ষক</option>
<option value="জুনিয়র শিক্ষক">জুনিয়র শিক্ষক</option>
<option value="সহকারি প্রধান শিক্ষক">সহকারী প্রধান শিক্ষক</option>
<option value="প্রাক-প্রাথমিক শিক্ষক">প্রাক-প্রাথমিক শিক্ষক</option>
<option value="সিনিয়র শিক্ষক">সিনিয়র শিক্ষক</option>

</select>
  
<td align='center'><b>Photo</b></td>
</td></tr>

<tr>

<td width='25%'> নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type='text' name='name' placeholder='সম্পূর্ণ নাম' required> 

</td>

<td rowspan='8' align='center'>আপনার <b>ছবি</b> এবং <b>স্বাক্ষর</b> এর লিংক কপি পেস্ট করুন। <br>
<b> ছবি </b>
 
<input name='photo' type='text' style='width: 150px;' required>

<b> স্বাক্ষর</b>
  
<input name='sign' type='text' style='width: 150px;' required>

<a href='demo-picture.html' target='_blank'> কীভাবে ছবি এবং স্বাক্ষর এর লিংক কপি পেস্ট করবেন, তা জানতে এখানে ক্লিক করুন!</a>
</td>
</tr>

<tr><td> Name </td> 
<td align='center' width='5%'>:</td>
<td width='48%'> 

<input type='text' name='ename' placeholder='FULL NAME' required> 

</td>
</tr>

<tr><td width='15%'> পিতার নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='fname' type='text' required> 

</td>
</tr>

<tr><td width='15%'> Father's Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='fename' type='text' required> 

</td>
</tr>

<tr><td width='15%'> মাতার নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='mname' type='text' required> 

</td>
</tr>

<tr><td width='15%'> Mother's Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='mename' type='text' required> 

</td>
</tr>

<tr><td width='15%'> জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type='text' placeholder='Type in English: dd/mm/yyyy' name='dob' required> 

</td>
</tr>

<tr><td width='15%'> জন্ম স্থান (জেলা) </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='pob' type='text' required> 

</td>
</tr>

<tr><td width='15%'> বিষয় </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='bisoy' type='text' placeholder='পড়ানোর বিষয়' required> 

</td>
</tr>

<tr><td width='15%' calspan='2'> লিঙ্গ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<select name="gen" required>
<option value="">নির্বাচন করুন...</option>
<option value="পুরুষ">পুরুষ</option>
<option value="মহিলা">মহিলা</option>
</select> 
  
</td>
</tr>

<tr><td width='15%'> জাতীয়তা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='nat' type='text' value='বাংলাদেশী' required> 

</td>
</tr>

<tr><td width='15%'> জন্মনিবন্ধন নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='brn' type='text' placeholder='Type in English' > 

</td>
</tr>

<tr><td width='15%'> NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='nid' type='text' placeholder='Type in English' required> 

</td>
</tr>

<tr><td width='15%'> পাসপোর্ট নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='pid' type='text'> 

</td>
</tr>

<tr><td width='15%'> ধর্ম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<select name="rel" required>
<option value="">নির্বাচন করুন...</option>
<option value="ইসলাম ধর্ম">ইসলাম ধর্ম</option>
<option value="হিন্দু ধর্ম">হিন্দু ধর্ম</option>
<option value="বৌদ্ধ ধর্ম">বৌদ্ধ ধর্ম</option>
<option value="খৃস্টান ধর্ম">খৃস্টান ধর্ম</option>
<option value="অন্যান্য">অন্যান্য</option>
</select>  
  
</td>
</tr>

<tr><td width='15%'>সম্পূর্ণ বর্তমান ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='3'> 

<input type='text2' name='pad' placeholder='হোল্ডিং নম্বর, ওয়ার্ড নম্বর, মহল্লা, ডাকঘর+কোড, থানা, জেলা' required> 

</td>
</tr>

<tr><td width='15%'>সম্পূর্ণ স্থায়ী ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type='text2' name='pead' placeholder='হোল্ডিং নম্বর, ওয়ার্ড নম্বর, মহল্লা, ডাকঘর+কোড, থানা, জেলা' required> 

</td>
</tr>

<tr><td width='15%'> মোবাইল নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mob' type='text' placeholder='Type in English' required> 

</td>
</tr>

<tr><td width='15%'> ই-মেইল </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='email' type='text' required> 

</td>
</tr>

<tr><td width='15%'> রক্তের গ্রুপ </td> <td align='center' width='5%'>:</td>
<td colspan='2'>   
<select name="blood" required>
<option value="">নির্বাচন করুন...</option>
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
</select>  
  </td>
</tr>   
   
<tr><td width='15%'> বৈবাহিক অবস্থা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<select name="mar" required>
<option value="">নির্বাচন করুন...</option>
<option value="বিবাহিত">বিবাহিত</option>
<option value="অবিবাহিত">অবিবাহিত</option>
<option value="বিধবা/বিপত্নীক">বিধবা/বিপত্নীক</option>
<option value="তালাকপ্রাপ্ত">তালাকপ্রাপ্ত</option>
<option value="অজানা">অজানা</option>
</select>
  
  </td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='husb' type='text'> 

</td>
</tr>

<tr><td width='15%'> Husband/Wife Name </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='huse' type='text' placeholder='Type in English'> 

</td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='hbirth' type='text' placeholder='Type in English'> 

</td>
</tr>


<tr><td width='15%'> স্বামী/স্ত্রীর NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='hnid' type='text'> 

</td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='hwork' type='text'> 

</td>
</tr>

<tr><td width='15%'> পিতার জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='fbirth' type='text' placeholder='Type in English' required> 

</td>
</tr>

<tr><td width='15%'> পিতা কি মৃত ? </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
<select name="fdead" required>
<option value="">নির্বাচন করুন...</option>
<option value="না">না</option>
<option value="হ্যা">হ্যা</option>
</select> 
</td>
</tr>

<tr><td width='15%'> পিতার NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='fnid' type='text' required> 

</td>
</tr>

<tr><td width='15%'> পিতার পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='fwork' type='text' required> 

</td>
</tr>

<tr><td width='15%'> মাতার জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mbirth' type='text' placeholder='Type in English' required> 

</td>
</tr>

<tr><td width='15%'> মাতা কি মৃত ? </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="mdead" required>
<option value="">নির্বাচন করুন...</option>
<option value="না">না</option>
<option value="হ্যা">হ্যা</option>
</select> 

</td>
</tr>

<tr><td width='15%'> মাতার NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mnid' type='text' required> 

</td>
</tr>

<tr><td width='15%'> মাতার পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mwork' type='text' required> 

</td>
</tr>

<tr><td width='15%'> আপনার ১ম সন্তানের নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cnam' type='text'> 

</td>
</tr>

<tr><td width='15%'> Your 1st Child Name </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cname' type='text' placeholder='Type in English'> 

</td>
</tr>

<tr><td width='15%'> ১ম সন্তানের জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cbirth' type='text' placeholder='Type in English'> 

</td>
</tr>


<tr><td width='15%'>  ১ম সন্তানের BID/NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cnid' type='text'> 

</td>
</tr>

<tr><td width='15%'> ১ম সন্তানের পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cwork' type='text'> 

</td>
</tr>

<tr><td width='15%'> প্রথম যোগদানের তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='att' type='text'  placeholder='Type in English: dd/mm/yyyy' required> 

</td>
</tr>
   
<tr><td width='15%'> প্রশিক্ষণের তথ্য (যদি থাকে) </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='pp' type='text2' placeholder='প্রশিক্ষণের নাম, প্রশিক্ষণ শুরু হওয়ার তারিখ, শেষ হওয়ার তারিখ'> 

</td>
</tr>

</table>

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>

<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> SSC or Equivalent Level 
</tr>

<tr align='center'>
<td>Examination Name 
<br>

<input name='xm' type='text' required>

Result 

<input name='res' type='text' required>

</td> 
<td>

Board
<br>

<input name='brd' type='text' required>

Group/Subject

<input name='grp' type='text' required>

</td> 
<td>

Roll Number

<br>

<input name='rl' type='text' required>

Passing Year 

<input name='py' type='text' required>

</td></tr></table>

<center> Registration Number <br>
<input name='rg1' type='text' required></center> 

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>

<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> 

HSC or Equivalent Level 
</tr>
<tr align='center'>
<td>Examination Name 
<br>

<input name='xm2' type='text' required>

Result 

<input name='res2' type='text' required>

</td> 
<td>

Board

<br>

<input name='brd2' type='text' required>

Group/Subject

<input name='grp2' type='text' required>

</td> 
<td>

Roll Number
<br>

<input name='rl2' type='text' required>

Passing Year
 
<input name='py2' type='text' required>

</td></tr></table>
<center> Registration Number <br>
<input name='rg2' type='text' required></center> 

<!-- _______________________________ -->
<br>

<table width='100%' border='1'>
<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> Graduation or Equivalent Level  
</tr>
<tr align='center'>
<td>

Examination Name 

<br>

<input name='xm3' type='text'>

Result 

<input name='res3' type='text'>

</td> 

<td>

Subject/Degree

<br>

<input name='sub' type='text'>

Course Duration 

<input name='crs' type='text'>

</td> 
<td>

University/Institute 

<br>
<input name='uni' type='text'>

 Passing Year

<input name='py3' type='text'>

</td></tr></table>
<center>Registration Number<br>
<input name='rg3' type='text'></center> 

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>
<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> Masters or Equivalent Level   
</tr>
<tr align='center'>
<td>

Examination Name 

<br>

<input name='xm4' type='text'>

Result 

<input name='res4' type='text'>

</td> 
<td>

Subject/Degree

<br>

<input name='sub2' type='text'>

Course Duration 

<input name='crs2' type='text'>

</td> 
<td>

University/Institute 

<br>

<input name='uni2' type='text'>

Passing Year 

<input name='py4' type='text'>

</td></tr></table>
<center>Registration Number<br>
<input name='rg4' type='text'></center> 

  <br> 
<center> <font color='red'>আবেদন সাবমিট করার পূর্বে অবশ্যই আপনার তথ্যগুলো ভালোভাবে পূণরায় চেক করে নিন। <br> 
    কারণ, আবেদন সাবমিট করার পর আপনি আপনার তথ্য আর সংশোধন করতে পারবেন না। </font></center>  
    
<center> <input type="submit" value="Submit" /> </center>
                 
</form>
</html>

