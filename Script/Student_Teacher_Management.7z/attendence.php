<?php
// Get year and month from request or use current
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');

// Validate month and year
if ($month < 1 || $month > 12) $month = (int)date('m');
if ($year < 2000 || $year > 2100) $year = (int)date('Y');

// Calculate days in month and month name
$daysInMonth = date('t', strtotime("$year-$month-01"));
$monthName = date('F Y', strtotime("$year-$month-01"));

// Load students from JSON file
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Get filter parameters
$filter_class = $_GET['class'] ?? '';

// Bangla number conversion
function en2bnNumber($number) {
    $bangla_numbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    $english_numbers = range(0, 9);
    return str_replace($english_numbers, $bangla_numbers, $number);
}

// Function to check if a date is a holiday (Friday/Saturday or other holidays)
function isHoliday($date) {
    $dayOfWeek = date('D', strtotime($date));
    // Friday and Saturday are weekends in Bangladesh
    if ($dayOfWeek == 'Fri' || $dayOfWeek == 'Sat') {
        return true;
    }
    
    // Add other holidays here (format: 'Y-m-d')
    $holidays = [
        // Example holidays - add your actual holidays here
        date('Y') . '-03-26', // Independence Day
        date('Y') . '-12-16', // Victory Day
        // Add more holidays as needed
    ];
    
    return in_array(date('Y-m-d', strtotime($date)), $holidays);
}

// Function to get month navigation links
function getMonthNavigation($year, $month) {
    $prevMonth = $month - 1;
    $prevYear = $year;
    if ($prevMonth < 1) {
        $prevMonth = 12;
        $prevYear--;
    }
    
    $nextMonth = $month + 1;
    $nextYear = $year;
    if ($nextMonth > 12) {
        $nextMonth = 1;
        $nextYear++;
    }
    
    return [
        'prev' => ['year' => $prevYear, 'month' => $prevMonth],
        'next' => ['year' => $nextYear, 'month' => $nextMonth],
        'current' => ['year' => (int)date('Y'), 'month' => (int)date('m')]
    ];
}

$monthNav = getMonthNavigation($year, $month);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Register - <?php echo $monthName; ?></title>
    <link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
    <style>
        body {
            font-family: Arial, kalpurush;
            margin: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        a {
            color: #0000ff;
            text-decoration: none;
        }
        a:hover {
            color: red;
        }
        .register-container {
            width: 100%;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 5px;
            text-align: center;
            min-width: 30px;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .holiday {
            background-color: #ffecec;
            color: #d32f2f;
        }

        .name-col {
            text-align: left;
            min-width: 200px;
        }
        .serial-col {
            width: 40px;
        }
        .date-col {
            min-width: 25px;
        }
        .print-btn {
            margin: 20px auto;
            display: block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .month-navigation {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        .month-nav-btn {
            padding: 5px 15px;
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
        }
        .month-nav-btn:hover {
            background-color: #e6e6e6;
        }
        .current-month-btn {
            background-color: #4CAF50;
            color: white;
        }
@media print {
  .no-print {
    visibility: hidden;
    color: green;
  }
}       
        
    </style>
</head>
<body>
<br><br>
<table style="border: none;">
<tr>
<td><img src="https://i.postimg.cc/vmkyysjG/200x200.png" height="100px" width="80px">
</td>
<td>
    <font size="06"><b>শিক্ষা স্কুল অ্যান্ড কলেজ, রাজশাহী</b></font><br>
    ১৮৫, দাশপুকুর মোড়, সিটি বাইপাস, রাজশাহী। মোবাইল: ০১৭৭০-৬৫৫৮৩১, web: www.sscraj.com, email: sscraj2013@gmail.com<br>
    <b>শিক্ষার্থীদের হাজিরা বহি</b><br>
    <center style="padding:3px;"></center>
    <b><?php echo $monthName; ?></b>
</td>
<td>
</td>
</tr>
</table>


<div class="filters">
    <form method="get">
        <input type="hidden" name="year" value="<?= $year ?>">
        <input type="hidden" name="month" value="<?= $month ?>">
        <div class="filter-group">
            <label for="class">Class:</label>
            <select name="class">
                <option value="">select</option>
                <?php
                // Get unique classes from students
                $classes = array_unique(array_column($students, 'class'));
                sort($classes);
                foreach ($classes as $class) {
                    $selected = $filter_class == $class ? 'selected' : '';
                    echo "<option value=\"$class\" $selected>$class</option>";
                }
                ?>
            </select>
            <button type="submit">Go</button>
            <a href="index.php" class="no-print" >Home</a>
        
            
    <a href="?year=<?= $monthNav['prev']['year'] ?>&month=<?= $monthNav['prev']['month'] ?><?= $filter_class ? '&class='.urlencode($filter_class) : '' ?>" class="no-print" style="color: green;">| &larr; <?= date('F', mktime(0, 0, 0, $monthNav['prev']['month'], 1)) ?></a>
    
    <a href="?year=<?= $monthNav['current']['year'] ?>&month=<?= $monthNav['current']['month'] ?><?= $filter_class ? '&class='.urlencode($filter_class) : '' ?>" class="no-print" style="color: indigo;">| Current |</a>
    
    <a href="?year=<?= $monthNav['next']['year'] ?>&month=<?= $monthNav['next']['month'] ?><?= $filter_class ? '&class='.urlencode($filter_class) : '' ?>" class="no-print" style="color: green;"><?= date('F', mktime(0, 0, 0, $monthNav['next']['month'], 1)) ?> &rarr;</a>          
      
        
        </div>
    </form>
</div>
<br>
<div class="register-ontainer">
    <table width="100%" border="1">
        <thead>
            <tr>
                <th class="serial-col">ক্রমিক</th>
                <th class="name-col">শিক্ষার্থীর নাম</th>
                <?php
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $date = "$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
                    $isHoliday = isHoliday($date);
                    
                    $cellClass = $isHoliday ? 'holiday' : '';
                    echo "<th class='date-col $cellClass'>" . en2bnNumber($day) . "</th>";
                }
                ?>
                <th>উপ.</th>
                <th>অনু.</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Filter students by class if selected
            $filteredStudents = array_filter($students, function($student) use ($filter_class) {
                return empty($filter_class) || $student['class'] == $filter_class;
            });

            foreach ($filteredStudents as $index => $student) {
                echo "<tr>";
                echo "<td>" . en2bnNumber(htmlspecialchars($student['roll'] ?? '')) . "</td>";
                echo "<td class='name-col'>" . htmlspecialchars($student['name_bangla'] ?? '') . "</td>";
                
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $date = "$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
                    $isHoliday = isHoliday($date);
                    
                    if ($isHoliday) {
                        echo "<td class='holiday'>ছুটি</td>";
                    } else {
                        echo "<td><div class='tick-box'></div></td>";
                    }
                }
                
                echo "<td></td>";
                echo "<td></td>";
                echo "</tr>";
            }
            
            // Add blank rows at the end____________#_________#________
            for ($i = 1; $i <= 2; $i++) {
                echo "<tr>";
                echo "<td></td>";
                echo "<td class='name-col'></td>";
                
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $date = "$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
                    $isHoliday = isHoliday($date);
                    
                    if ($isHoliday) {
                        echo "<td class='holiday'>ছুটি</td>";
                    } else {
                        echo "<td><div class='tick-box'></div></td>";
                    }
                }
                
                echo "<td></td>";
                echo "<td></td>";
                echo "</tr>";
            }
			
			// Add blank rows at the end
            for ($i = 1; $i <= 1; $i++) {
                echo "<tr>";
                echo "<td></td>";
                echo "<td class='name-col' style='text-align:right;'>প্রতিদিনের মোট উপস্থিতি</td>";
                
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $date = "$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
                    $isHoliday = isHoliday($date);
                    
                    if ($isHoliday) {
                        echo "<td class='holiday'>ছুটি</td>";
                    } else {
                        echo "<td><div class='tick-box'></div></td>";
                    }
                }
                
                echo "<td></td>";
                echo "<td></td>";
                echo "</tr>";
            }
            ?>
        </tbody>
        
      
    </table>
</div>


</body>
</html>