<?php
require_once 'config.php';

function is_logged_in() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

function redirect_if_not_logged_in() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function attempt_login($password) {
    global $system_password;
    if ($password === $system_password) {
        $_SESSION['logged_in'] = true;
        return true;
    }
    return false;
}
?>