<?php

// Load students from file
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Change Filtering ###
$filter_class = $_GET['class'] ?? '';
$filter_name = $_GET['name'] ?? '';
$filter_section = $_GET['section'] ?? '';
$filter_gender = $_GET['gender'] ?? '';
$filter_group = $_GET['group'] ?? '';
$filter_roll = $_GET['roll'] ?? '';

// Change Filtering ###
$filteredStudents = array_filter($students, function($student) use ($filter_class, $filter_name, $filter_section, $filter_gender, $filter_group, $filter_roll) {
    return (empty($filter_class) || stripos($student['class'], $filter_class) !== false) &&
           (empty($filter_name) || stripos($student['name_english'], $filter_name) !== false || 
                                 stripos($student['name_bangla'], $filter_name) !== false) &&
           (empty($filter_section) || stripos($student['section'], $filter_section) !== false) &&
           (empty($filter_gender) || stripos($student['gender'], $filter_gender) !== false) &&
           (empty($filter_group) || stripos($student['group'], $filter_group) !== false) &&
           (empty($filter_roll) || stripos($student['roll'], $filter_roll) !== false);
});


$totalStudents = count($filteredStudents);

// Group by class and calculate statistics
$studentsByClass = [];
$classStatistics = [];

foreach ($filteredStudents as $student) {
    $class = $student['class'];
    if (!isset($studentsByClass[$class])) {
        $studentsByClass[$class] = [];
        $classStatistics[$class] = [
            'total' => 0,
            'male' => 0,
            'female' => 0,
            'groups' => []
        ];
    }
    $studentsByClass[$class][] = $student;
    
    // Update statistics
    $classStatistics[$class]['total']++;
    if (stripos($student['gender'], '*Male') !== false) {
        $classStatistics[$class]['male']++;
    } else {
        $classStatistics[$class]['female']++;
    }
    
    // Group count
    $group = $student['group'] ?? 'None';
    if (!isset($classStatistics[$class]['groups'][$group])) {
        $classStatistics[$class]['groups'][$group] = 0;
    }
    $classStatistics[$class]['groups'][$group]++;
}

// Sort classes
ksort($studentsByClass);

?>

<!DOCTYPE html>
<html>
<head>
<link href='https://asikurbd.github.io/wi/admn3.png' rel='icon' type='image/x-icon'/>
    <title>Call Report </title>
	<style>
table {
  table-layout: fixed;
}
table {
	border-collapse: collapse;
	color: #000;
	font-size: 16px;
	text-align: left;
}

td {
	padding: 4px;
	color: black;
}
body{	
	font-family: Arial, kalpurush;
	max-width:850px; 
	margin: 0 auto;
	padding: 1px;
	margin-top:10px;
	margin-bottom:10px;
	border: 0px solid #040e9b;
}

a {
	text-decoration: none; 
}

a:hover { 
  	color: red;
 }
  
</style> 

</head>
<body>

    
    <div class="filters">
<center>            
         <form method="get">
    <select name="class" onChange="window.location.href=this.value">
   
    <option value="?class=Junior-One" <?php echo (isset($filter_class) && $filter_class == 'Junior-One') ? 'selected' : ''; ?>>Junior One</option>
    <option value="?class=Nursery" <?php echo (isset($filter_class) && $filter_class == 'Nursery') ? 'selected' : ''; ?>>Nursery</option>
    <option value="?class=1" <?php echo (isset($filter_class) && $filter_class == '1') ? 'selected' : ''; ?>>1</option>
    <option value="?class=2" <?php echo (isset($filter_class) && $filter_class == '2') ? 'selected' : ''; ?>>2</option>
    <option value="?class=3" <?php echo (isset($filter_class) && $filter_class == '3') ? 'selected' : ''; ?>>3</option>
    <option value="?class=4" <?php echo (isset($filter_class) && $filter_class == '4') ? 'selected' : ''; ?>>4</option>
    <option value="?class=5" <?php echo (isset($filter_class) && $filter_class == '5') ? 'selected' : ''; ?>>5</option>
    <option value="?class=6" <?php echo (isset($filter_class) && $filter_class == '6') ? 'selected' : ''; ?>>6</option>
    <option value="?class=7" <?php echo (isset($filter_class) && $filter_class == '7') ? 'selected' : ''; ?>>7</option>
    <option value="?class=8" <?php echo (isset($filter_class) && $filter_class == '8') ? 'selected' : ''; ?>>8</option>
    <option value="?class=9" <?php echo (isset($filter_class) && $filter_class == '9') ? 'selected' : ''; ?>>9</option>
    <option value="?class=Ten" <?php echo (isset($filter_class) && $filter_class == 'Ten') ? 'selected' : ''; ?>>10</option>
    </select>
            <a href="index.php">Home</a>
        </form>
		</center>  
    </div>    


	
    <?php foreach ($studentsByClass as $class => $classStudents): ?>
    <br>
    <div style="background:#e1e1e1;padding:5px; border-top: 1px solid #000;border-left: 1px solid #000;border-right: 1px solid #000;">  <center>
            <b>Call Report, Class: <?php echo htmlspecialchars($class); ?></b>
        </center></div>
     
        
        <table width="100%" border="1">
            <tr bgcolor="#e1e1e1" style="text-align: center;">
                <td width="6%">ক্রমিক</td>
                <td width="30%">শিক্ষার্থীর নাম</td> 
                <td width="18%">মোবাইল নম্বর</td>
				<td width="15%"> তারিখ ও মন্তব্য <br><br></td> 
				<td width="15%">তারিখ ও মন্তব্য<br><br></td> 
				<td width="15%">তারিখ ও মন্তব্য<br><br></td> 
				<td width="15%">তারিখ ও মন্তব্য<br><br></td> 
            </tr>
            <?php foreach ($classStudents as $student): ?>
            <tr>
            <td style='text-align: center;' width="6%">
			
<?php 
$englishDigits = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$banglaDigits = array('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯');

$roll = htmlspecialchars($student['roll']);
$banglaRoll = str_replace($englishDigits, $banglaDigits, $roll);
echo $banglaRoll;
?>
            </td>
            <td width="30%">
            <?php echo htmlspecialchars($student['name_bangla']); ?>
            </td>

            <td style="text-align: center;font-size:14px;" width="18%">
            <?php echo htmlspecialchars($student['mobile']); ?>
            </td>
			<td> </td>
			<td> </td>
			<td> </td>
			<td> </td>
			<td> </td>

    
            </tr>
            <?php endforeach; ?>
            <!-- Add 2 extra empty rows -->
            <tr>
                <td style='text-align: center;' width="6%"> &nbsp;</td>
                <td width="30%"></td>
                <td style="text-align: center;font-size:14px;" width="18%"></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td style='text-align: center;' width="6%">&nbsp;</td>
                <td width="30%"></td>
                <td style="text-align: center;font-size:14px;" width="18%"></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </table>
		
    <?php endforeach; ?>

</body>
</html>