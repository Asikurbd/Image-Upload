<?php
// Password configuration
$system_password = '2255'; // Change this to your desired password

// Session configuration
session_start();

// Other configurations
define('MAX_FILE_SIZE', 1024 * 1024); // 1MB for JSON file
?>