
<?php
require_once 'auth.php';
redirect_if_not_logged_in();

// Load students
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Find and remove student
$studentId = $_GET['id'] ?? null;

foreach ($students as $key => $student) {
    if ($student['id'] == $studentId) {
        unset($students[$key]);
        break;
    }
}

// Re-index array and save
$students = array_values($students);
file_put_contents('students.json', json_encode($students));

// Redirect to list
header('Location: index.php');
exit;
?>