<?php
require_once 'auth.php';
redirect_if_not_logged_in();

// Load teachers
$teachers = [];
if (file_exists('teachers.json')) {
    $teachers = json_decode(file_get_contents('teachers.json'), true) ?: [];
}

// Find and remove teacher
$teacherId = $_GET['id'] ?? null;

foreach ($teachers as $key => $teacher) {
    if ($teacher['id'] == $teacherId) {
        unset($teachers[$key]);
        break;
    }
}

// Re-index array and save
$teachers = array_values($teachers);
file_put_contents('teachers.json', json_encode($teachers));

// Redirect to list
header('Location: manage-teacher.php');
exit;
?>