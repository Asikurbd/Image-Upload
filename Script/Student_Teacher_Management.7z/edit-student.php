<?php
require_once 'auth.php';
redirect_if_not_logged_in();


// Load students
$students = [];
if (file_exists('students.json')) 

{
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Find student by ID
$student = null;
$studentId = $_GET['id'] ?? null;

foreach ($students as $key => $s) {
    if ($s['id'] == $studentId) {
        $student = $s;
        $studentKey = $key;
        break;
    }
}

if (!$student) {
    header('Location: index.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $students[$studentKey] = [
        'id' => $student['id'],
        'roll' => $_POST['roll'],
        'class' => $_POST['class'],
		'bio_id' => $_POST['bio_id'],
		'group' => $_POST['group'],
        'section' => $_POST['section'],
        'name_bangla' => $_POST['name_bangla'],
        'name_english' => $_POST['name_english'],
        'dob' => $_POST['dob'],
        'birth_certificate' => $_POST['birth_certificate'],
        'mobile' => $_POST['mobile'],
        'gender' => $_POST['gender'],
        'blood_group' => $_POST['blood_group'],
        'father_name_bangla' => $_POST['father_name_bangla'],
        'father_name_english' => $_POST['father_name_english'],
        'father_dob' => $_POST['father_dob'],
        'father_nid' => $_POST['father_nid'],
        'mother_name_bangla' => $_POST['mother_name_bangla'],
        'mother_name_english' => $_POST['mother_name_english'],
        'mother_dob' => $_POST['mother_dob'],
        'mother_nid' => $_POST['mother_nid'],
		'present_address' => $_POST['present_address'],
		'permanent_paddress' => $_POST['permanent_paddress'],
		'photo' => $_POST['photo'],
		'sign' => $_POST['sign'],
		'rel' => $_POST['rel'],
    ];
    
    // Save to file
    file_put_contents('students.json', json_encode($students));
    
    // Redirect to list
    header('Location: index.php');
    exit;
}
?>



<head>
  	<meta charset="utf-8" />
   	<title>Edit Student</title>
  	<link rel="stylesheet" href="style.css" />
  	<link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>

<html>
  

<form method="post">
                
<table width='100%' border='1'>
 
<tr>
<td> 

Serial

</td> <td align='center' width='5%'>:</td>
<td> 

 <input type="text" id="roll" name="roll" value="<?php echo htmlspecialchars($student['roll']); ?>">
 
<td align='center'><b>Photo</b></td>
</td></tr>

<tr>

<td width='25%'> Class </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<select name="class" Type="text">
	<option value="Junior-One" <?php echo ($student['class'] ?? '') === 'Junior-One' ? 'selected' : ''; ?>>Junior One</option>
	<option value="Nursery" <?php echo ($student['class'] ?? '') === 'Nursery' ? 'selected' : ''; ?>>Nursery</option>
    <option value="1" <?php echo ($student['class'] ?? '') === '1' ? 'selected' : ''; ?>>1</option>
	<option value="2" <?php echo ($student['class'] ?? '') === '2' ? 'selected' : ''; ?>>2</option>
	<option value="3" <?php echo ($student['class'] ?? '') === '3' ? 'selected' : ''; ?>>3</option>
	<option value="4" <?php echo ($student['class'] ?? '') === '4' ? 'selected' : ''; ?>>4</option>
    <option value="5" <?php echo ($student['class'] ?? '') === '5' ? 'selected' : ''; ?>>5</option>
	<option value="6" <?php echo ($student['class'] ?? '') === '6' ? 'selected' : ''; ?>>6</option>
	<option value="7" <?php echo ($student['class'] ?? '') === '7' ? 'selected' : ''; ?>>7</option>
	<option value="8" <?php echo ($student['class'] ?? '') === '8' ? 'selected' : ''; ?>>8</option>
    <option value="9" <?php echo ($student['class'] ?? '') === '9' ? 'selected' : ''; ?>>9</option>
    <option value="Ten" <?php echo ($student['class'] ?? '') === 'Ten' ? 'selected' : ''; ?>>10</option>
</select>
</td>

<td rowspan='7' align='center'><b>ছবি</b> এবং <b>স্বাক্ষর</b> এর লিংক। <br>
<b> ছবি </b>
 
<input type="text" id="photo" name="photo" value="<?php echo htmlspecialchars($student['photo']); ?>" style='width: 150px;' >

<b> স্বাক্ষর</b>
  
<input type="text" id="sign" name="sign" value="<?php echo htmlspecialchars($student['sign']); ?>" style='width: 150px;' >

</td>
</tr>

<tr><td> Section </td> 
<td align='center' width='5%'>:</td>
<td width='48%'> 


<select name="section" Type="text">
	<option value="Red" <?php echo ($student['section'] ?? '') === 'Red' ? 'selected' : ''; ?>>Red</option>
	<option value="Green" <?php echo ($student['section'] ?? '') === 'Green' ? 'selected' : ''; ?>>Green</option>
</select>

</td>
</tr>

<tr><td width='15%'> <b>Full Name </b></td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" id="name_english" name="name_english" value="<?php echo htmlspecialchars($student['name_english']); ?>">

</td>
</tr>

<tr><td width='15%'><b> সম্পূর্ণ নাম </b></td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" id="name_bangla" name="name_bangla" value="<?php echo htmlspecialchars($student['name_bangla']); ?>">

</td>
</tr>

<tr><td width='15%'> Date Of Birth </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" id="dob" name="dob" value="<?php echo htmlspecialchars($student['dob']); ?>">

</td>
</tr>

<tr><td width='15%'> Birth Certificate No </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" id="birth_certificate" name="birth_certificate" value="<?php echo htmlspecialchars($student['birth_certificate']); ?>">

</td>
</tr>

<tr><td width='15%'> Mobile Number </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

 <input type="text" id="mobile" name="mobile" value="<?php echo htmlspecialchars($student['mobile']); ?>">

</td>
</tr>

<tr><td width='15%'> Student ID</td> <td align='center' width='5%'>:</td><td colspan='2'> 

 <input type="text" id="bio_id" name="bio_id" value="<?php echo htmlspecialchars($student['bio_id']); ?>">

</td></tr>

<tr><td width='15%'> Group</td> <td align='center' width='5%'>:</td><td colspan='2'> 

<select name="group">
<option value="N/A" <?php echo ($student['group'] ?? '') === 'N/A' ? 'selected' : ''; ?>>N/A</option>
<option value="Science+H.M" <?php echo ($student['group'] ?? '') === 'Science+H.M' ? 'selected' : ''; ?>>Science+H.M</option>
<option value="Science+Agri" <?php echo ($student['group'] ?? '') === 'Science+Agri' ? 'selected' : ''; ?>>Science+Agri</option>
<option value="Arts+Agri" <?php echo ($student['group'] ?? '') === 'Arts+Agri' ? 'selected' : ''; ?>>Arts+Agri</option>
<option value="Commerce" <?php echo ($student['group'] ?? '') === 'Commerce' ? 'selected' : ''; ?>>Commerce</option>
</select>
</td></tr>

<tr><td width='15%'> Gender</td> <td align='center' width='5%'>:</td><td colspan='2'>  

<select name="gender">
<option value="*Male" <?php echo ($student['gender'] ?? '') === '*Male' ? 'selected' : ''; ?>>*Male</option>
<option value="Female" <?php echo ($student['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
</select>

</td>
</tr>

<tr><td width='15%'> Blood Group </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="blood_group">
<option value="A+" <?php echo ($student['blood_group'] ?? '') === 'A+' ? 'selected' : ''; ?>>A+</option>
<option value="A-" <?php echo ($student['blood_group'] ?? '') === 'A-' ? 'selected' : ''; ?>>A-</option>
<option value="B+" <?php echo ($student['blood_group'] ?? '') === 'B+' ? 'selected' : ''; ?>>B+</option>
<option value="B-" <?php echo ($student['blood_group'] ?? '') === 'B-' ? 'selected' : ''; ?>>B-</option>
<option value="AB+" <?php echo ($student['blood_group'] ?? '') === 'AB+' ? 'selected' : ''; ?>>AB+</option>
<option value="AB-" <?php echo ($student['blood_group'] ?? '') === 'AB-' ? 'selected' : ''; ?>>AB-</option>
<option value="O+" <?php echo ($student['blood_group'] ?? '') === 'O+' ? 'selected' : ''; ?>>O+</option>
<option value="O-" <?php echo ($student['blood_group'] ?? '') === 'O-' ? 'selected' : ''; ?>>O-</option>
</select>

</td>
</tr>

<tr><td width='15%' calspan='2'> ধর্ম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="rel" required>
<option value="ইসলাম ধর্ম" <?php echo ($student['rel'] ?? '') === 'ইসলাম ধর্ম' ? 'selected' : ''; ?>>ইসলাম ধর্ম</option>
<option value="হিন্দু ধর্ম" <?php echo ($student['rel'] ?? '') === 'হিন্দু ধর্ম' ? 'selected' : ''; ?>>হিন্দু ধর্ম</option>
<option value="বৌদ্ধ ধর্ম" <?php echo ($student['rel'] ?? '') === 'বৌদ্ধ ধর্ম' ? 'selected' : ''; ?>>বৌদ্ধ ধর্ম</option>
<option value="খৃস্টান ধর্ম" <?php echo ($student['rel'] ?? '') === 'খৃস্টান ধর্ম' ? 'selected' : ''; ?>>খৃস্টান ধর্ম</option>
<option value="অন্যান্য" <?php echo ($student['rel'] ?? '') === 'অন্যান্য' ? 'selected' : ''; ?>>অন্যান্য</option>
</select> 
  
</td>
</tr>

<tr><td width='15%'> বর্তমান ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text2" id="present_address" name="present_address" value="<?php echo htmlspecialchars($student['present_address']); ?>">

</td>
</tr>

<tr><td width='15%'> স্থায়ী ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text2" id="permanent_paddress" name="permanent_paddress" value="<?php echo htmlspecialchars($student['permanent_paddress']); ?>">

</td>
</tr>

<tr><td width='15%'> Father's Name (English)</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" id="father_name_english" name="father_name_english" value="<?php echo htmlspecialchars($student['father_name_english']); ?>">

</td>
</tr>

<tr><td width='15%'> পিতার নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" id="father_name_bangla" name="father_name_bangla" value="<?php echo htmlspecialchars($student['father_name_bangla']); ?>">

</td>
</tr>

<tr><td width='15%'> Father's Date of Birth</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
 <input type="text" id="father_dob" name="father_dob" value="<?php echo htmlspecialchars($student['father_dob']); ?>">
  
</td>
</tr>

<tr><td width='15%'>Father's NID No </td> <td align='center' width='5%'>:</td>
<td colspan='3'> 

<input type="text" id="father_nid" name="father_nid" value="<?php echo htmlspecialchars($student['father_nid']); ?>">

</td>
</tr>

<tr><td width='15%'>Mother's Name (English)</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" id="mother_name_english" name="mother_name_english" value="<?php echo htmlspecialchars($student['mother_name_english']); ?>">

</td>
</tr>

<tr><td width='15%'> মাতার নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" id="mother_name_bangla" name="mother_name_bangla" value="<?php echo htmlspecialchars($student['mother_name_bangla']); ?>">

</td>
</tr>

<tr><td width='15%'> Mother's Date of Birth </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type="text" id="mother_dob" name="mother_dob" value="<?php echo htmlspecialchars($student['mother_dob']); ?>">

</td>
</tr>

<!-- copy this table -->

<tr><td width='15%'> Mother's NID No </td> <td align='center' width='5%'>:</td><td colspan='2'>  
 
<input type="text" id="mother_nid" name="mother_nid" value="<?php echo htmlspecialchars($student['mother_nid']); ?>"> 

</td></tr>  
<!-- copy end this table -->
 

</table> 
    
<center> <input type="submit" value="Update Student" /> </center>
                 
</form>
</html>

