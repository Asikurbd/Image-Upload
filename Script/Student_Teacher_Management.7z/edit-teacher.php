
<?php
require_once 'auth.php';
redirect_if_not_logged_in();

// Load teachers
$teachers = [];
if (file_exists('teachers.json')) {
    $teachers = json_decode(file_get_contents('teachers.json'), true) ?: [];
}

// Find teacher by ID
$teacher = null;
$teacherId = $_GET['id'] ?? null;

foreach ($teachers as $key => $t) {
    if ($t['id'] == $teacherId) {
        $teacher = $t;
        $teacherKey = $key;
        break;
    }
}

if (!$teacher) {
    header('Location: index.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teachers[$teacherKey] = [
        'id' => $teacher['id'],
        
		        'post' => $_POST['post'],
        'name' => $_POST['name'],
		'ename' => $_POST['ename'],
		'fname' => $_POST['fname'],
		'fename' => $_POST['fename'],
		'mname' => $_POST['mname'],
		'mename' => $_POST['mename'],
		'dob' => $_POST['dob'],
		'pob' => $_POST['pob'],
		'gen' => $_POST['gen'],
		'nat' => $_POST['nat'],
		'brn' => $_POST['brn'],
		'nid' => $_POST['nid'],
		'pid' => $_POST['pid'],
		'rel' => $_POST['rel'],
		'pad' => $_POST['pad'],
		'pead' => $_POST['pead'],
		'mob' => $_POST['mob'],
		'email' => $_POST['email'],
		'mar' => $_POST['mar'],
		'xm' => $_POST['xm'],
		'res' => $_POST['res'],
		'brd' => $_POST['brd'],
		'grp' => $_POST['grp'],
		'rl' => $_POST['rl'],
		'py' => $_POST['py'],
		'att' => $_POST['att'],
		'pp' => $_POST['pp'],
		'blood' => $_POST['blood'],
		'xm2' => $_POST['xm2'],
		'res2' => $_POST['res2'],
		'brd2' => $_POST['brd2'],
		'grp2' => $_POST['grp2'],
		'rl2' => $_POST['rl2'],
		'py2' => $_POST['py2'],
		'xm3' => $_POST['xm3'],
		'res3' => $_POST['res3'],
		'sub' => $_POST['sub'],
		'crs' => $_POST['crs'],
		'uni' => $_POST['uni'],
		'py3' => $_POST['py3'],
		'xm4' => $_POST['xm4'],
		'res4' => $_POST['res4'],
		'sub2' => $_POST['sub2'],
		'crs2' => $_POST['crs2'],
		'uni2' => $_POST['uni2'],
		'py4' => $_POST['py4'],
		'photo' => $_POST['photo'],
		'sign' => $_POST['sign'],
		'bisoy' => $_POST['bisoy'],
		'husb' => $_POST['husb'],
		'huse' => $_POST['huse'],
		'hbirth' => $_POST['hbirth'],
		'hnid' => $_POST['hnid'],
		'hwork' => $_POST['hwork'],
		'fbirth' => $_POST['fbirth'],
		'fdead' => $_POST['fdead'],
		'fnid' => $_POST['fnid'],
		'fwork' => $_POST['fwork'],
		'mbirth' => $_POST['mbirth'],
		'mdead' => $_POST['mdead'],
		'mnid' => $_POST['mnid'],
		'mwork' => $_POST['mwork'],
		'cnam' => $_POST['cnam'],
		'cname' => $_POST['cname'],
		'cbirth' => $_POST['cbirth'],
		'cnid' => $_POST['cnid'],
		'cwork' => $_POST['cwork'],
		'rg1' => $_POST['rg1'],
		'rg2' => $_POST['rg2'],
		'rg3' => $_POST['rg3'],
		'rg4' => $_POST['rg4'],
		'#' => $_POST['#'],
		'#' => $_POST['#'],
		
		
    ];
    
    // Save to file
    file_put_contents('teachers.json', json_encode($teachers));
    
    // Redirect to list
    header('Location: manage-teacher.php');
    exit;
}
?>



<head>
  	<meta charset="utf-8" />
   	<title>Edit Teachers</title>
  	<link rel="stylesheet" href="style.css" />
  	<link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>

<html>
  

<form method="post">
                
<table width='100%' border='1'>
 
<tr>
<td> পদবী </td> <td align='center' width='5%'>:</td>
<td> 
  
<select name="post">
    <option value="">নির্বাচন করুন...</option>
    <option value="সহকারী শিক্ষক" <?php echo ($teacher['post'] ?? '') === 'সহকারী শিক্ষক' ? 'selected' : ''; ?>>সহকারী শিক্ষক</option>
    <option value="জুনিয়র শিক্ষক" <?php echo ($teacher['post'] ?? '') === 'জুনিয়র শিক্ষক' ? 'selected' : ''; ?>>জুনিয়র শিক্ষক</option>
    <option value="সহকারী প্রধান শিক্ষক" <?php echo ($teacher['post'] ?? '') === 'সহকারী প্রধান শিক্ষক' ? 'selected' : ''; ?>>সহকারী প্রধান শিক্ষক</option>
    <option value="প্রাক-প্রাথমিক শিক্ষক" <?php echo ($teacher['post'] ?? '') === 'প্রাক-প্রাথমিক শিক্ষক' ? 'selected' : ''; ?>>প্রাক-প্রাথমিক শিক্ষক</option>
    <option value="সিনিয়র শিক্ষক" <?php echo ($teacher['post'] ?? '') === 'সিনিয়র শিক্ষক' ? 'selected' : ''; ?>>সিনিয়র শিক্ষক</option>
</select>
  
<td align='center'><b>Photo</b></td>
</td></tr>

<tr>

<td width='25%'> নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type="text" name="name" value="<?php echo htmlspecialchars($teacher['name']); ?>">

</td>

<td rowspan='8' align='center'><b>ছবি</b> এবং <b>স্বাক্ষর</b> এর লিংক কপি পেস্ট করুন। <br>
<b> ছবি </b>
 
<input name='photo' type='text' style='width: 150px;' value="<?php echo htmlspecialchars($teacher['photo']); ?>">

<b> স্বাক্ষর</b>
  
<input name='sign' type='text' style='width: 150px;' value="<?php echo htmlspecialchars($teacher['sign']); ?>">

<a href='demo-picture.html' target='_blank'> demo</a>
</td>
</tr>

<tr><td> Name </td> 
<td align='center' width='5%'>:</td>
<td width='48%'> 

<input type='text' name='ename' value="<?php echo htmlspecialchars($teacher['ename']); ?>"> 

</td>
</tr>

<tr><td width='15%'> পিতার নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='fname' type='text' value="<?php echo htmlspecialchars($teacher['fname']); ?>">

</td>
</tr>

<tr><td width='15%'> Father's Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='fename' type='text' value="<?php echo htmlspecialchars($teacher['fename']); ?>">

</td>
</tr>

<tr><td width='15%'> মাতার নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='mname' type='text' value="<?php echo htmlspecialchars($teacher['mname']); ?>">

</td>
</tr>

<tr><td width='15%'> Mother's Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='mename' type='text' value="<?php echo htmlspecialchars($teacher['mename']); ?>">

</td>
</tr>

<tr><td width='15%'> জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input type='text' name='dob' value="<?php echo htmlspecialchars($teacher['dob']); ?>">

</td>
</tr>

<tr><td width='15%'> জন্ম স্থান (জেলা) </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<input name='pob' type='text' value="<?php echo htmlspecialchars($teacher['pob']); ?>">

</td>
</tr>

<tr><td width='15%'> বিষয় </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='bisoy' type='text' value="<?php echo htmlspecialchars($teacher['bisoy']); ?>">

</td>
</tr>

<tr><td width='15%' calspan='2'> লিঙ্গ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<select name="gen" required>
<option value="পুরুষ" <?php echo ($teacher['gen'] ?? '') === 'পুরুষ' ? 'selected' : ''; ?>>পুরুষ</option>
<option value="মহিলা" <?php echo ($teacher['gen'] ?? '') === 'মহিলা' ? 'selected' : ''; ?>>মহিলা</option>
</select>
  
</td>
</tr>

<tr><td width='15%'> জাতীয়তা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='nat' type='text' value="<?php echo htmlspecialchars($teacher['nat']); ?>">

</td>
</tr>

<tr><td width='15%'> জন্মনিবন্ধন নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='brn' type='text' value="<?php echo htmlspecialchars($teacher['brn']); ?>"> 

</td>
</tr>

<tr><td width='15%'> NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='nid' type='text' value="<?php echo htmlspecialchars($teacher['nid']); ?>">

</td>
</tr>

<tr><td width='15%'> পাসপোর্ট নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='pid' type='text' value="<?php echo htmlspecialchars($teacher['pid']); ?>"> 

</td>
</tr>

<tr><td width='15%'> ধর্ম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<select name="rel">
<option value="ইসলাম ধর্ম" <?php echo ($teacher['rel'] ?? '') === 'ইসলাম ধর্ম' ? 'selected' : ''; ?>>ইসলাম ধর্ম</option>
<option value="হিন্দু ধর্ম" <?php echo ($teacher['rel'] ?? '') === 'হিন্দু ধর্ম' ? 'selected' : ''; ?>>হিন্দু ধর্ম</option>
<option value="বৌদ্ধ ধর্ম" <?php echo ($teacher['rel'] ?? '') === 'বৌদ্ধ ধর্ম' ? 'selected' : ''; ?>>বৌদ্ধ ধর্ম</option>
<option value="খৃস্টান ধর্ম" <?php echo ($teacher['rel'] ?? '') === 'খৃস্টান ধর্ম' ? 'selected' : ''; ?>>খৃস্টান ধর্ম</option>
<option value="অন্যান্য" <?php echo ($teacher['rel'] ?? '') === 'অন্যান্য' ? 'selected' : ''; ?>>অন্যান্য</option>
</select>  
  
</td>
</tr>

<tr><td width='15%'>সম্পূর্ণ বর্তমান ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='3'> 

<input type='text2' name='pad' value="<?php echo htmlspecialchars($teacher['pad']); ?>">

</td>
</tr>

<tr><td width='15%'>সম্পূর্ণ স্থায়ী ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input type='text2' name='pead' value="<?php echo htmlspecialchars($teacher['pead']); ?>">

</td>
</tr>

<tr><td width='15%'> মোবাইল নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mob' type='text' value="<?php echo htmlspecialchars($teacher['mob']); ?>">

</td>
</tr>

<tr><td width='15%'> ই-মেইল </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='email' type='text' value="<?php echo htmlspecialchars($teacher['email']); ?>">

</td>
</tr>

<tr><td width='15%'> রক্তের গ্রুপ </td> <td align='center' width='5%'>:</td>
<td colspan='2'>   

<select name="blood">
<option value="A+" <?php echo ($teacher['blood'] ?? '') === 'A+' ? 'selected' : ''; ?>>A+</option>
<option value="A-" <?php echo ($teacher['blood'] ?? '') === 'A-' ? 'selected' : ''; ?>>A-</option>
<option value="B+" <?php echo ($teacher['blood'] ?? '') === 'B+' ? 'selected' : ''; ?>>B+</option>
<option value="B-" <?php echo ($teacher['blood'] ?? '') === 'B-' ? 'selected' : ''; ?>>B-</option>
<option value="AB+" <?php echo ($teacher['blood'] ?? '') === 'AB+' ? 'selected' : ''; ?>>AB+</option>
<option value="AB-" <?php echo ($teacher['blood'] ?? '') === 'AB-' ? 'selected' : ''; ?>>AB-</option>
<option value="O+" <?php echo ($teacher['blood'] ?? '') === 'O+' ? 'selected' : ''; ?>>O+</option>
<option value="O-" <?php echo ($teacher['blood'] ?? '') === 'O-' ? 'selected' : ''; ?>>O-</option>
</select>

  </td>
</tr>   
   
<tr><td width='15%'> বৈবাহিক অবস্থা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<select name="mar">
<option value="বিবাহিত" <?php echo ($teacher['mar'] ?? '') === 'বিবাহিত' ? 'selected' : ''; ?>>বিবাহিত</option>
<option value="অবিবাহিত" <?php echo ($teacher['mar'] ?? '') === 'অবিবাহিত' ? 'selected' : ''; ?>>অবিবাহিত</option>
<option value="বিধবা/বিপত্নীক" <?php echo ($teacher['mar'] ?? '') === 'বিধবা/বিপত্নীক' ? 'selected' : ''; ?>>বিধবা/বিপত্নীক</option>
<option value="তালাকপ্রাপ্ত" <?php echo ($teacher['mar'] ?? '') === 'তালাকপ্রাপ্ত' ? 'selected' : ''; ?>>তালাকপ্রাপ্ত</option>
</select>
  
  </td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='husb' type='text' value="<?php echo htmlspecialchars($teacher['husb']); ?>">

</td>
</tr>

<tr><td width='15%'> Husband/Wife Name </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='huse' type='text' value="<?php echo htmlspecialchars($teacher['huse']); ?>">

</td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='hbirth' type='text' value="<?php echo htmlspecialchars($teacher['hbirth']); ?>">

</td>
</tr>


<tr><td width='15%'> স্বামী/স্ত্রীর NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='hnid' type='text' value="<?php echo htmlspecialchars($teacher['hnid']); ?>"> 

</td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='hwork' type='text' value="<?php echo htmlspecialchars($teacher['hwork']); ?>">

</td>
</tr>

<tr><td width='15%'> পিতার জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='fbirth' type='text' value="<?php echo htmlspecialchars($teacher['fbirth']); ?>">

</td>
</tr>

<tr><td width='15%'> পিতা কি মৃত ? </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="fdead">
<option value="না" <?php echo ($teacher['fdead'] ?? '') === 'না' ? 'selected' : ''; ?>>না</option>
<option value="হ্যা" <?php echo ($teacher['fdead'] ?? '') === 'হ্যা' ? 'selected' : ''; ?>>হ্যা</option>
</select> 

</td>
</tr>

<tr><td width='15%'> পিতার NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='fnid' type='text' value="<?php echo htmlspecialchars($teacher['fnid']); ?>">

</td>
</tr>

<tr><td width='15%'> পিতার পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='fwork' type='text' value="<?php echo htmlspecialchars($teacher['fwork']); ?>">

</td>
</tr>

<tr><td width='15%'> মাতার জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mbirth' type='text' value="<?php echo htmlspecialchars($teacher['mbirth']); ?>">

</td>
</tr>

<tr><td width='15%'> মাতা কি মৃত ? </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<select name="mdead">
<option value="না" <?php echo ($teacher['mdead'] ?? '') === 'না' ? 'selected' : ''; ?>>না</option>
<option value="হ্যা" <?php echo ($teacher['mdead'] ?? '') === 'হ্যা' ? 'selected' : ''; ?>>হ্যা</option>
</select> 

</td>
</tr>

<tr><td width='15%'> মাতার NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mnid' type='text' value="<?php echo htmlspecialchars($teacher['mnid']); ?>">

</td>
</tr>

<tr><td width='15%'> মাতার পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='mwork' type='text' value="<?php echo htmlspecialchars($teacher['mwork']); ?>">

</td>
</tr>

<tr><td width='15%'> আপনার ১ম সন্তানের নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cnam' type='text' value="<?php echo htmlspecialchars($teacher['cnam']); ?>">

</td>
</tr>

<tr><td width='15%'> Your 1st Child Name </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cname' type='text' value="<?php echo htmlspecialchars($teacher['cname']); ?>">

</td>
</tr>

<tr><td width='15%'> ১ম সন্তানের জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cbirth' type='text' value="<?php echo htmlspecialchars($teacher['cbirth']); ?>">

</td>
</tr>


<tr><td width='15%'>  ১ম সন্তানের BID/NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cnid' type='text' value="<?php echo htmlspecialchars($teacher['cnid']); ?>">

</td>
</tr>

<tr><td width='15%'> ১ম সন্তানের পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='cwork' type='text' value="<?php echo htmlspecialchars($teacher['cwork']); ?>">

</td>
</tr>

<tr><td width='15%'> প্রথম যোগদানের তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='att' type='text' value="<?php echo htmlspecialchars($teacher['att']); ?>">

</td>
</tr>
   
<tr><td width='15%'> প্রশিক্ষণের তথ্য (যদি থাকে) </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<input name='pp' type='text2' value="<?php echo htmlspecialchars($teacher['pp']); ?>">

</td>
</tr>

</table>

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>

<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> SSC or Equivalent Level 
</tr>

<tr align='center'>
<td>Examination Name 
<br>

<input name='xm' type='text' value="<?php echo htmlspecialchars($teacher['xm']); ?>">


Result 

<input name='res' type='text' value="<?php echo htmlspecialchars($teacher['res']); ?>">

</td> 
<td>

Board
<br>

<input name='brd' type='text' value="<?php echo htmlspecialchars($teacher['brd']); ?>">

Group/Subject

<input name='grp' type='text' value="<?php echo htmlspecialchars($teacher['grp']); ?>">

</td> 
<td>

Roll Number

<br>

<input name='rl' type='text' value="<?php echo htmlspecialchars($teacher['rl']); ?>">

Passing Year 

<input name='py' type='text' value="<?php echo htmlspecialchars($teacher['py']); ?>">

</td></tr></table>

<center> Registration Number <br>
<input name='rg1' type='text' value="<?php echo htmlspecialchars($teacher['rg1']); ?>"></center> 

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>

<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> 

HSC or Equivalent Level 
</tr>
<tr align='center'>
<td>Examination Name 
<br>

<input name='xm2' type='text' value="<?php echo htmlspecialchars($teacher['xm2']); ?>">

Result 

<input name='res2' type='text' value="<?php echo htmlspecialchars($teacher['res2']); ?>">

</td> 
<td>

Board

<br>

<input name='brd2' type='text' value="<?php echo htmlspecialchars($teacher['brd2']); ?>">

Group/Subject

<input name='grp2' type='text' value="<?php echo htmlspecialchars($teacher['grp2']); ?>">

</td> 
<td>

Roll Number
<br>

<input name='rl2' type='text' value="<?php echo htmlspecialchars($teacher['rl2']); ?>">

Passing Year
 
<input name='py2' type='text' value="<?php echo htmlspecialchars($teacher['py2']); ?>">

</td></tr></table>
<center> Registration Number <br>
<input name='rg2' type='text' value="<?php echo htmlspecialchars($teacher['rg2']); ?>"></center> 

<!-- _______________________________ -->
<br>

<table width='100%' border='1'>
<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> Graduation or Equivalent Level  
</tr>
<tr align='center'>
<td>

Examination Name 

<br>

<input name='xm3' type='text' value="<?php echo htmlspecialchars($teacher['xm3']); ?>">

Result 

<input name='res3' type='text' value="<?php echo htmlspecialchars($teacher['res3']); ?>">

</td> 

<td>

Subject/Degree

<br>

<input name='sub' type='text' value="<?php echo htmlspecialchars($teacher['sub']); ?>">

Course Duration 

<input name='crs' type='text' value="<?php echo htmlspecialchars($teacher['crs']); ?>">

</td> 
<td>

University/Institute 

<br>

<input name='uni' type='text' value="<?php echo htmlspecialchars($teacher['uni']); ?>">

 Passing Year

<input name='py3' type='text' value="<?php echo htmlspecialchars($teacher['py3']); ?>">

</td></tr></table>
<center>Registration Number<br>

<input name='rg3' type='text' value="<?php echo htmlspecialchars($teacher['rg3']); ?>">
</center> 

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>
<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> Masters or Equivalent Level   
</tr>
<tr align='center'>
<td>

Examination Name 

<br>

<input name='xm4' type='text' value="<?php echo htmlspecialchars($teacher['xm4']); ?>">

Result 

<input name='res4' type='text' value="<?php echo htmlspecialchars($teacher['res4']); ?>">

</td> 
<td>

Subject/Degree

<br>

<input name='sub2' type='text' value="<?php echo htmlspecialchars($teacher['sub2']); ?>">

Course Duration 

<input name='crs2' type='text' value="<?php echo htmlspecialchars($teacher['crs2']); ?>">

</td> 
<td>

University/Institute 

<br>

<input name='uni2' type='text' value="<?php echo htmlspecialchars($teacher['uni2']); ?>">

Passing Year 
<input name='py4' type='text' value="<?php echo htmlspecialchars($teacher['py4']); ?>">

</td></tr></table>
<center>Registration Number<br>
<input name='rg4' type='text' value="<?php echo htmlspecialchars($teacher['rg4']); ?>">
</center> 

  <br> 

    
<center> <input type="submit" value="Update Teacher" /> </center>
                 
</form>
</html>