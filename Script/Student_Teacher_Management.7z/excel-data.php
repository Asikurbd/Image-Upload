<?php

require_once 'auth.php';
redirect_if_not_logged_in();

// Load students from file
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Change Filtering ###
$filter_class = $_GET['class'] ?? '';
$filter_name = $_GET['name'] ?? '';
$filter_section = $_GET['section'] ?? '';
$filter_father_name_bangla = $_GET['father_name_bangla'] ?? '';
$filter_gender = $_GET['gender'] ?? '';
$filter_group = $_GET['group'] ?? '';
$filter_roll = $_GET['roll'] ?? '';

// Bangla number conversion
function en2bnNumber($number) {
    $bangla_numbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    $english_numbers = range(0, 9);
    return str_replace($english_numbers, $bangla_numbers, $number);
}


// Change Filtering ###
$filteredStudents = array_filter($students, function($student) use ($filter_class, $filter_name, $filter_section, $filter_gender, $filter_group, $filter_father_name_bangla, $filter_roll) {
	
	
    return (empty($filter_class) || stripos($student['class'], $filter_class) !== false) &&
           (empty($filter_name) || stripos($student['name_english'], $filter_name) !== false || 
                                 stripos($student['name_bangla'], $filter_name) !== false) &&
           (empty($filter_section) || stripos($student['section'], $filter_section) !== false) &&
           (empty($filter_gender) || stripos($student['gender'], $filter_gender) !== false) &&
           (empty($filter_group) || stripos($student['group'], $filter_group) !== false) &&
		   (empty($filter_father_name_bangla) || stripos($student['father_name_bangla'], $filter_father_name_bangla) !== false) &&
           (empty($filter_roll) || stripos($student['roll'], $filter_roll) !== false);
});


$totalStudents = count($filteredStudents);

// Group by class and calculate statistics
$studentsByClass = [];
$classStatistics = [];

foreach ($filteredStudents as $student) {
    $class = $student['class'];
    if (!isset($studentsByClass[$class])) {
        $studentsByClass[$class] = [];
        $classStatistics[$class] = [
            'total' => 0,
            'male' => 0,
            'female' => 0,
            'groups' => []
        ];
    }
    $studentsByClass[$class][] = $student;
    
    // Update statistics
    $classStatistics[$class]['total']++;
    if (stripos($student['gender'], '*Male') !== false) {
        $classStatistics[$class]['male']++;
    } else {
        $classStatistics[$class]['female']++;
    }
    
    // Group count
    $group = $student['group'] ?? 'None';
    if (!isset($classStatistics[$class]['groups'][$group])) {
        $classStatistics[$class]['groups'][$group] = 0;
    }
    $classStatistics[$class]['groups'][$group]++;
}

// Sort classes
ksort($studentsByClass);
?>

<!DOCTYPE html>
<html>
<head>
<link href='excel-style.css' rel='stylesheet' type='text/css'/>
<link href='https://asikurbd.github.io/wi/admn3.png' rel='icon' type='image/x-icon'/>
    <title>Management System</title>

</head>
<body>
    <center>    
        <h1>
        <div style="background:#e1e1e1;"> 
        Teacher & Student Management System
        </div>
        </h1>
            <a href="add-student.php">Add New Student</a> | <a href="attendence.php">Attendence Page</a> | <a href="call-report.php?class=Junior-One">Call Report</a> | <a href="add-teacher.php">Add New Teacher</a> | <a href="manage-teacher.php">Manage Teacher</a> | <a href="st-admit-card.php?class=Nursery">Admit Card</a> | <a href="https://www.sscraj.com/cv/files/files%2FG/mimsms.php"> SMS Send </a>| <a href="excel-data.php">Excel Data</a> <br> |
			<a href="index.php">Index</a> |
    </center><hr>
    
    <div class="filters">
        <center> <h3>Filter Students</h3> </center>
        
         <form method="get">
         
         <center>
        <table width="100%" align="center">
        <tr bgcolor="#e1e1e1" ‍align="center">
        <td align="center"> Class <br>
        
    <select name="class">
    <option value="">Select</option>
    <option value="Junior-One" <?php echo (isset($filter_class) && $filter_class == 'Junior-One') ? 'selected' : ''; ?>>Junior One</option>
    <option value="Nursery" <?php echo (isset($filter_class) && $filter_class == 'Nursery') ? 'selected' : ''; ?>>Nursery</option>
    <option value="1" <?php echo (isset($filter_class) && $filter_class == '1') ? 'selected' : ''; ?>>1</option>
    <option value="2" <?php echo (isset($filter_class) && $filter_class == '2') ? 'selected' : ''; ?>>2</option>
    <option value="3" <?php echo (isset($filter_class) && $filter_class == '3') ? 'selected' : ''; ?>>3</option>
    <option value="4" <?php echo (isset($filter_class) && $filter_class == '4') ? 'selected' : ''; ?>>4</option>
    <option value="5" <?php echo (isset($filter_class) && $filter_class == '5') ? 'selected' : ''; ?>>5</option>
    <option value="6" <?php echo (isset($filter_class) && $filter_class == '6') ? 'selected' : ''; ?>>6</option>
    <option value="7" <?php echo (isset($filter_class) && $filter_class == '7') ? 'selected' : ''; ?>>7</option>
    <option value="8" <?php echo (isset($filter_class) && $filter_class == '8') ? 'selected' : ''; ?>>8</option>
    <option value="9" <?php echo (isset($filter_class) && $filter_class == '9') ? 'selected' : ''; ?>>9</option>
    <option value="Ten" <?php echo (isset($filter_class) && $filter_class == 'Ten') ? 'selected' : ''; ?>>10</option>
    </select>
    
        
        </td>
        <td align="center"> Name <br>
         <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($filter_name); ?>">
        </td> 
        <td align="center">Father Name<br>
        
  <input type="text" id="father_name_bangla" name="father_name_bangla" value="<?php echo htmlspecialchars($filter_father_name_bangla); ?>">
        
        </td>
        </tr>
        <tr bgcolor="#e1e1e1" align="center">
        <td bgcolor="#e1e1e1">Serial <br>
         <input type="text" id="roll" name="roll" value="<?php echo htmlspecialchars($filter_roll); ?>">
         <center style="padding:6px;"></center>	
		 </td>
         <td bgcolor="#e1e1e1">
            Gender<br>
    <select name="gender">
    <option value="">Select</option>
    <option value="*Male" <?php echo (isset($filter_gender) && $filter_gender == '*Male') ? 'selected' : ''; ?>>Male</option>
    <option value="Female" <?php echo (isset($filter_gender) && $filter_gender == 'Female') ? 'selected' : ''; ?>>Female</option>
    </select>
<center style="padding:6px;"></center>		
         </td>
         <td bgcolor="#e1e1e1">
            Group
            <br>
            <input type="text" id="group" name="group" value="<?php echo htmlspecialchars($filter_group); ?>">
         <center style="padding:6px;"></center>		
		 </td>
         </tr>
         </table> 

</center>         
          <center style="padding:4px;"></center>	
            <center><input type="submit" value="Apply">
            <a href="excel-data.php">Reset</a></center>
        </form>
    </div>    

 <br><center>Total Students in School: <b><font color="red"><?php echo $totalStudents; ?> </font></b> </center>
	
    <?php foreach ($studentsByClass as $class => $classStudents): ?>
    <br>
    <div style="background:#e1e1e1;padding:5px; border-top: 1px solid #000;border-left: 1px solid #000;border-right: 1px solid #000;">  <center>
            <b>Class: <?php echo htmlspecialchars($class); ?></b>
        </center></div>
       
        
<style>
table {
  table-layout: fixed;
}
</style>        
        
        <table width="100%" border="1">
            <tr bgcolor="#e1e1e1" style="text-align: center;">
                <td width="4%">Photo</td>
				<td width="2%">ক্রমিক</td>
				<td width="5%">ST ID</td>
                <td>শিক্ষার্থীর নাম</td>
				<td>Student Name</td>
                <td>পিতার নাম</td>
				<td>Father's Name</td>
                <td>মাতার নাম</td>
				<td>Mother's Name</td>
                <td>মোবাইল নম্বর</td>
                <td width="4%">Gender</td>                                
                <td width="5%">Actions</td>
				<td>ঠিকানা</td>
            </tr>
            <?php foreach ($classStudents as $student): ?>
            <tr>
			<td>
			<img src='https://www.sscraj.com/cv/files/files/St-img/2025/<?php echo htmlspecialchars($student['class']); ?>/<?php echo htmlspecialchars($student['roll']); ?>.jpg' height='60px' width='60px'>
			</td>
            <td style='text-align: center;'>
			<a href="view-student.php?id=<?php echo $student['id']; ?>">
            <?php echo en2bnNumber(htmlspecialchars($student['roll'] ?? '')); ?>
			</a>
            </td>
			<td style="text-align: center;">
            <?php echo htmlspecialchars($student['bio_id']); ?>
            </td>
            <td>
            <?php echo htmlspecialchars($student['name_bangla']); ?>
            </td>
            <td>
            <?php echo htmlspecialchars($student['name_english']); ?>
            </td>			
            <td>
            <?php echo htmlspecialchars($student['father_name_bangla']); ?>
            </td>
			<td>
            <?php echo htmlspecialchars($student['father_name_english']); ?>
            </td>
            <td>
            <?php echo htmlspecialchars($student['mother_name_bangla']); ?>
            </td>
			 <td>
            <?php echo htmlspecialchars($student['mother_name_english']); ?>
            </td>
            <td style="text-align: center;">
            <?php echo htmlspecialchars($student['mobile']); ?>
            </td>
            <td style="text-align: center;">
            <?php echo htmlspecialchars($student['gender']); ?>
            </td>
            <td style="text-align: center;">
            <a href="edit-student.php?id=<?php echo $student['id']; ?>">
            <img src="https://asikurbd.github.io/wi/pnt.png"/></a>
            
            <a href="view-student.php?id=<?php echo $student['id']; ?>">
            <img src="https://asikurbd.github.io/wi/eye.png"/></a>   

			<a href="prottayon.php?id=<?php echo $student['id']; ?>">  
			<img src="https://asikurbd.github.io/wi/nt1.png"/>
			</a>                  
            </td>
			 <td style="text-align: center;">
            <?php echo htmlspecialchars($student['present_address']); ?>
            </td>
            </tr>
            <?php endforeach; ?>
        </table>
<center>
<center style="padding:3px;"></center>		
<table width="80%" border="1">
<tr>
<td>
Total= <b><?php echo $classStatistics[$class]['total']; ?></b>
</td>
<td>
Male= <b><?php echo $classStatistics[$class]['male']; ?></b>
</td>
<td>
Female= <b><?php echo $classStatistics[$class]['female']; ?></b>
</td>
<td width="40%">
Groups= <b><?php foreach ($classStatistics[$class]['groups'] as $group => $count): ?>
<?php echo htmlspecialchars($group) ?>: <?php echo $count; ?></b>
<?php endforeach; ?>
</td>
</tr>
</table>
</center>
		
    <?php endforeach; ?>
    <br>    
    <center><a href="logout.php">Logout</a></center>
    <br>
</body>
</html>