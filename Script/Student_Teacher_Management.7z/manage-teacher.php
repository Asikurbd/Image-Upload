<?php

require_once 'auth.php';
redirect_if_not_logged_in();

// Load teachers from file
$teachers = [];
if (file_exists('teachers.json')) {
    $teachers = json_decode(file_get_contents('teachers.json'), true) ?: [];
}

// Filtering
$filter_name = $_GET['name'] ?? '';
$filter_mob = $_GET['mob'] ?? '';

$filtered_teachers = array_filter($teachers, function($teacher) use ($filter_name, $filter_mob) {
    return (empty($filter_name) || stripos($teacher['name'], $filter_name) !== false) &&
           (empty($filter_mob) || stripos($teacher['mob'], $filter_mob) !== false);
});

?>

<!DOCTYPE html>
<html>
<head>
    <link href='https://asikurbd.github.io/wi/admn3.png' rel='icon' type='image/x-icon'/>
    <link href='style.css' rel='stylesheet' type='text/css'/>
    <title>Teacher Management System</title>
</head>
<body>
    <center>	
        <h1>
            <div style="background:#e1e1e1;"> 
                Teacher Management System
            </div>
        </h1>
     <a href="index.php">Home</a> | <a href="add-teacher.php">Add New Teacher</a>
    </center><hr>
    
    <div class="filters">
        <center><h3>Filter Teachers</h3></center>
        <form method="get">
            <center>
                <table width="100%" align="center">
                    <tr bgcolor="#e1e1e1" align="center">
                        <td align="center">Name<br>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($filter_name); ?>">
                        </td>
                        <td align="center">Mobile<br>
                            <input type="text" id="mob" name="mob" value="<?php echo htmlspecialchars($filter_mob); ?>">
                        </td>
                    </tr>
                </table> 
            </center>		 
            <center>
                <input type="submit" value="Apply Filters">
                <a href="manage-teacher.php">Reset</a>
            </center>
        </form>
		<br>
    </div>    

    <table width="100%" border="1">
        <tr bgcolor="#e1e1e1">
            <td width="25%">Name</td>
            <td width="25%">Father's Name</td>
            <td width="25%">Post</td>
            <td width="15%">Mobile</td>
            <td width="10%">Actions</td>
        </tr>
        <?php foreach ($filtered_teachers as $teacher): ?>
        <tr>
            <td><?php echo htmlspecialchars($teacher['name'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($teacher['fname'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($teacher['post'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($teacher['mob'] ?? ''); ?></td>
            <td>
                <a href="edit-teacher.php?id=<?php echo $teacher['id']; ?>">
                    <img src="https://asikurbd.github.io/wi/pnt.png"/></a>
                <a href="view-teacher.php?id=<?php echo $teacher['id']; ?>">
                    <img src="https://asikurbd.github.io/wi/eye.png"/></a>
                <a href="delete-teacher.php?id=<?php echo $teacher['id']; ?>" onclick="return confirm('Are you sure?')">
                    <img src="https://asikurbd.github.io/wi/ddd.png"/></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <br>	
    <center><a href="logout.php">Logout</a></center>
    <br>
</body>
</html>

