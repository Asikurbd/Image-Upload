<?php
// Configuration
$api_username = 'tajmul13@gmail.com';
$api_key = 'L9H34870B5610R9';
$sender_id = '8809601002623';
$api_url = 'https://api.mimsms.com/api';
$site_name = 'Bulk SMS Sender';
$max_sms_length = 160; // This is now just for display purposes, not enforcement

// Initialize variables
$recipients = '';
$message = '';
$status = '';
$status_class = '';
$balance = '111.00';
$balance_status = 'success';
$success_count = 0;
$error_count = 0;
$results = [];

// Check balance on page load
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $balance_result = checkBalance($api_username, $api_key, $api_url);
    if (is_numeric($balance_result)) {
        $balance = number_format($balance_result, 2);
        $balance_status = 'success';
    } else {
        $balance = 'Error checking balance';
        $balance_status = 'error';
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_sms'])) {
    $recipients = trim($_POST['recipients']);
    $message = trim($_POST['message']);
    
    // Validate inputs
    if (empty($recipients) || empty($message)) {
        $status = 'Error: Recipient numbers and message are required';
        $status_class = 'error';
    } else {
        // Process multiple recipients
        $recipient_list = preg_split('/[\s,;\n]+/', $recipients);
        $recipient_list = array_filter($recipient_list);
        $recipient_list = array_unique($recipient_list);
        
        foreach ($recipient_list as $recipient) {
            $recipient = trim($recipient);
            if (!empty($recipient)) {
                $sms_result = sendSMS($recipient, $message, $api_username, $api_key, $sender_id, $api_url);
                
                if (strpos($sms_result, 'trxnId') !== false) {
                    $results[] = ['number' => $recipient, 'status' => 'Success', 'response' => $sms_result];
                    $success_count++;
                } else {
                    $results[] = ['number' => $recipient, 'status' => 'Failed', 'response' => $sms_result];
                    $error_count++;
                }
            }
        }
        
        // Update status message
        if ($success_count > 0 || $error_count > 0) {
            $status = "Sent to $success_count numbers successfully";
            if ($error_count > 0) {
                $status .= ", failed to send to $error_count numbers";
                $status_class = 'warning';
            } else {
                $status_class = 'success';
            }
            
            // Update balance after sending
            $new_balance = checkBalance($api_username, $api_key, $api_url);
            $balance = is_numeric($new_balance) ? number_format($new_balance, 2) : $balance;
        }
    }
}

// Function to send SMS
function sendSMS($to, $message, $username, $apiKey, $senderId, $apiUrl) {
    $to = '88' . ltrim($to, '88'); // Ensure proper format
    
    $postData = [
        "ApiKey" => $apiKey,
        "MobileNumber" => $to,
        "SenderName" => $senderId,
        "CampaignName" => "",
        "UserName" => $username,
        "TransactionType" => "T",
        "MessageId" => "",
        "Message" => $message,
        "CampaignId" => "null",
        "SmsData" => null
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrl.'/SmsSending/SMS',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($postData),
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: bearer'
        ]
    ]);

    $output = curl_exec($ch);
    if(curl_errno($ch)) {
        $output = 'error:' . curl_error($ch);
    }
    curl_close($ch);

    return $output;
}

// Function to check balance
function checkBalance($username, $apiKey, $apiUrl) {
    $postData = [
        'Apikey' => $apiKey,
        'UserName' => $username
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrl.'/SmsSending/balanceCheck',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($postData),
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: bearer'
        ]
    ]);

    $output = curl_exec($ch);
    if(curl_errno($ch)) {
        return 'error:' . curl_error($ch);
    }
    curl_close($ch);

    $result = json_decode($output, true);
    return isset($result['responseResult']) ? $result['responseResult'] : 'Error';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?></title>
    <link href="https://asikurbd.github.io/css/mimsms.css" rel="stylesheet" type="text/css"/>    
    <link href='https://asikurbd.github.io/wi/mon.png' rel='icon' type='image/x-icon'/>
    <style>
        .char-count.warning {
            color: orange;
        }
        .char-count.error {
            color: red;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1><a href=""><?php echo htmlspecialchars($site_name); ?></a></h1>
        
        <div class="balance <?php echo $balance_status; ?>">
            Current SMS Balance: <?php echo htmlspecialchars($balance); ?>
        </div>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="recipients">Recipient Numbers <span class="required">*</span></label>
                <textarea id="recipients" name="recipients" required
                          placeholder="Enter multiple numbers separated by commas, spaces, or new lines"><?php echo htmlspecialchars($recipients); ?></textarea>
                <div class="format-hint">
                    Format: 017XXXXXXXX, 88017XXXXXXXX (multiple numbers separated by commas, spaces or new lines)
                </div>
            </div>
            
            <div class="form-group">
                <label for="message">Message <span class="required">*</span></label>
                <textarea id="message" name="message" required
                          placeholder="Type your message here"><?php echo htmlspecialchars($message); ?></textarea>
                <div class="char-count" id="char-count-display">
                    <span id="char-count">0</span> characters (Long messages will be automatically split)
                </div>
            </div>
            
            <button type="submit" name="send_sms">Send Bulk SMS</button>
        </form>
        
        <?php if (!empty($status)): ?>
            <div id="status" class="<?php echo $status_class; ?>">
                <?php echo $status; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($results)): ?>
            <h3>Delivery Results:</h3>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Phone Number</th>
                        <th>Status</th>
                        <th>API Response</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $result): ?>
                        <tr class="<?php echo strtolower($result['status']) === 'success' ? 'success-row' : 'error-row'; ?>">
                            <td><?php echo htmlspecialchars($result['number']); ?></td>
                            <td><?php echo htmlspecialchars($result['status']); ?></td>
                            <td>&nbsp;</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <script>
        // Character count update
        document.getElementById('message').addEventListener('input', function() {
            const charCount = this.value.length;
            const charCountElement = document.getElementById('char-count');
            const charCountDisplay = document.getElementById('char-count-display');
            
            charCountElement.textContent = charCount;
            
            // Update display style based on length
            if (charCount > 160) {
                charCountDisplay.className = 'char-count warning';
            } else {
                charCountDisplay.className = 'char-count';
            }
        });
        
        // Initialize character count on page load
        document.addEventListener('DOMContentLoaded', function() {
            const message = document.getElementById('message');
            const charCount = message.value.length;
            document.getElementById('char-count').textContent = charCount;
            
            // Set initial style
            if (charCount > 160) {
                document.getElementById('char-count-display').className = 'char-count warning';
            }
        });
    </script>
</body>
</html>