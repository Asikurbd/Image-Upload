<?php
// Load students
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Find student by ID
$student = null;
$studentId = $_GET['id'] ?? null;

if ($studentId) {
    foreach ($students as $key => $s) {
        if (isset($s['id']) && $s['id'] == $studentId) {
            $student = $s;
            $studentKey = $key;
            break;
        }
    }
}

if (!$student) {
    header('Location: index.php');
    exit;
}

// Functions for Bangla conversion
function convertToBanglaNumber($input) {
    if (empty($input)) return '';
    
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-'];
    $bangla = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '-'];
    return str_replace($english, $bangla, $input);
}

function formatBanglaDate($dateString) {
    if (empty($dateString)) return '';
    
    try {
        $date = new DateTime($dateString);
        $day = $date->format('d');
        $month = $date->format('m');
        $year = $date->format('Y');
        
        return convertToBanglaNumber($day).'-'.convertToBanglaNumber($month).'-'.convertToBanglaNumber($year);
    } catch (Exception $e) {
        return $dateString; // Return original if date is invalid
    }
}

function convertToBanglaClass($class) {
    if (empty($class)) return '';
    
    $english = [
        'Nursery', 'Junior One', 
        '1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
        'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten'
    ];
    
    $bangla = [
        'নার্সারি', 'জুনিয়র ওয়ান', 
        'প্রথম', 'দ্বিতীয়', 'তৃতীয়', 'চতুর্থ', 'পঞ্চম', 'ষষ্ঠ', 'সপ্তম', 'অষ্টম', 'নবম', 'দশম',
        'প্রথম', 'দ্বিতীয়', 'তৃতীয়', 'চতুর্থ', 'পঞ্চম', 'ষষ্ঠ', 'সপ্তম', 'অষ্টম', 'নবম', 'দশম'
    ];
    
    return str_replace($english, $bangla, $class);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>প্রত্যায়ন পত্র</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>
<body>
<center><img src="https://i.postimg.cc/tghrrfTx/SSC.png" height="150px" width="100%"></center>


<table width="100%"><tr>
<td>
<div style="font-size: 20px;">


স্মারক: প্র.প-২০২৫/





</div>
</td>
<td align="right">
<div style="font-size: 20px;">
<?php
function todayBanglaDate() {
    // English to Bangla digit mapping
    $engDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-'];
    $banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '-'];
    
    // Get current date parts
    $day = date('d');
    $month = date('m');
    $year = date('Y');
    
    // Combine into date string
    $dateString = "$day-$month-$year";
    
    // Convert to Bangla digits
    return str_replace($engDigits, $banglaDigits, $dateString);
}

// Usage:
echo todayBanglaDate(); // Outputs today's date like: ০১-০১-২০২৫
?>
</div>
</td>
</tr>
</table>


<br><br><br><br><br>

<center><img src="https://i.postimg.cc/DzVyTWcX/pp.png" height="70px" width="210px"></center>
<br><br><br><br>
<div style="text-align: justify; line-height: 1.9;font-size: 20px;">
			এই মর্মে প্রত্যায়ন করা যাচ্ছে যে, <b>
			<?php echo htmlspecialchars($student['name_bangla'] ?? ''); ?></b>, পিতা:
			<?php echo htmlspecialchars($student['father_name_bangla'] ?? ''); ?>, মাতা:
			<?php echo htmlspecialchars($student['mother_name_bangla'] ?? ''); ?>, ঠিকানা:
			<?php echo htmlspecialchars($student['present_address'] ?? ''); ?>। 
			সে এই প্রতিষ্ঠানে ২০২৫ শিক্ষাবর্ষে 
			<?php echo convertToBanglaClass($student['class'] ?? ''); ?>
			শ্রেণিতে অধ্যয়নরত। 
			তার জন্মতারিখ: <?php echo formatBanglaDate($student['dob'] ?? ''); ?>।   
			তার আচার-আচরণ সন্তোষজনক।
			<br><br><br>
			আমি তাঁর ভবিষ্যত জীবন মঙ্গল কামনা করি।  
			<br><br><br><br><br>
			প্রধান শিক্ষক
   </div>
</body>
</html>