<?php

require_once 'auth.php';
redirect_if_not_logged_in();

// Load students from file
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Filtering
$filter_class = $_GET['class'] ?? '';

// Filter students by class
$filteredStudents = array_filter($students, function($student) use ($filter_class) {
    return empty($filter_class) || stripos($student['class'], $filter_class) !== false;
});

$totalStudents = count($filteredStudents);

// Group by class for statistics
$studentsByClass = [];
$classStatistics = [];

foreach ($filteredStudents as $student) {
    $class = $student['class'];
    if (!isset($studentsByClass[$class])) {
        $studentsByClass[$class] = [];
        $classStatistics[$class] = [
            'total' => 0,
            'male' => 0,
            'female' => 0,
            'groups' => []
        ];
    }
    $studentsByClass[$class][] = $student;
    
    // Update statistics
    $classStatistics[$class]['total']++;
    if (stripos($student['gender'], 'Male') !== false) {
        $classStatistics[$class]['male']++;
    } else {
        $classStatistics[$class]['female']++;
    }
    
    // Group count
    $group = $student['group'] ?? 'None';
    if (!isset($classStatistics[$class]['groups'][$group])) {
        $classStatistics[$class]['groups'][$group] = 0;
    }
    $classStatistics[$class]['groups'][$group]++;
}

// Sort classes
ksort($studentsByClass);


// ____#___________#_____

function convertToBanglaClass($class) {
    $english = array(
        'Nursery', 
        'Junior-One', 
        '1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
        'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten'
    );
    
    $bangla = array(
        'নার্সারি',
        'জুনিয়র ওয়ান', 
        'প্রথম', 'দ্বিতীয়', 'তৃতীয়', 'চতুর্থ', 'পঞ্চম', 'ষষ্ঠ', 'সপ্তম', 'অষ্টম', 'নবম', 'দশম',
        'প্রথম', 'দ্বিতীয়', 'তৃতীয়', 'চতুর্থ', 'পঞ্চম', 'ষষ্ঠ', 'সপ্তম', 'অষ্টম', 'নবম', 'দশম'
    );
    
    $converted = str_replace($english, $bangla, $class);
    return $converted;
}
// ____#___________#_____



?>

<!DOCTYPE html>
<html>
<head>
    <link href='https://asikurbd.github.io/wi/admn3.png' rel='icon' type='image/x-icon'/>
    <title>Student Admit Cards</title>
    <style>
        table {
            table-layout: fixed;
            border-collapse: collapse;
            color: #000;
            font-size: 17px;
            text-align: left;
        }
        td {
            padding: 4px;
            color: black;
        }
        body {
            font-family: Arial, kalpurush;
            max-width:800px; 
            margin: 0 auto;
            padding: 1px;
            margin-top:5px;
            margin-bottom:5px;
            border: 0px solid #040e9b;
        }
        a {
            text-decoration: none; 
        }
        a:hover { 
            color: red;
        }
        .id-card {
            border: 1px solid black;
            margin-bottom: 20px;
            page-break-inside: avoid;
        }
        .id-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .id-card {           
            margin-bottom: 30px;
        }
        @media print {
            .no-print {
                display: none;
            }
            .id-card {
                page-break-inside: avoid;
            }
            body {
                margin: 0;
                padding: 0;
            }
        }
        .filters {
            margin-bottom: 20px;
        }
    </style> 
</head>
<body>
    <div class="filters no-print">
        <center>            
            <form method="get">
                <select name="class" onchange="this.form.submit()">
                    <option value="">Select Class</option>
                    <option value="Junior-One" <?php echo ($filter_class == 'Junior-One') ? 'selected' : ''; ?>>Junior One</option>
                    <option value="Nursery" <?php echo ($filter_class == 'Nursery') ? 'selected' : ''; ?>>Nursery</option>
                    <option value="1" <?php echo ($filter_class == '1') ? 'selected' : ''; ?>>Class 1</option>
                    <option value="2" <?php echo ($filter_class == '2') ? 'selected' : ''; ?>>Class 2</option>
                    <option value="3" <?php echo ($filter_class == '3') ? 'selected' : ''; ?>>Class 3</option>
                    <option value="4" <?php echo ($filter_class == '4') ? 'selected' : ''; ?>>Class 4</option>
                    <option value="5" <?php echo ($filter_class == '5') ? 'selected' : ''; ?>>Class 5</option>
                    <option value="6" <?php echo ($filter_class == '6') ? 'selected' : ''; ?>>Class 6</option>
                    <option value="7" <?php echo ($filter_class == '7') ? 'selected' : ''; ?>>Class 7</option>
                    <option value="8" <?php echo ($filter_class == '8') ? 'selected' : ''; ?>>Class 8</option>
                    <option value="9" <?php echo ($filter_class == '9') ? 'selected' : ''; ?>>Class 9</option>
                    <option value="Ten" <?php echo ($filter_class == 'Ten') ? 'selected' : ''; ?>>Class 10</option>
                </select>
                <input type="submit" value="Show IDs">
                <a href="index.php">Home</a>
            </form>
            <?php if($filter_class): ?>
                <button onclick="window.print()" class="no-print">Print ID Cards</button>
                <p>Showing <?php echo count($filteredStudents); ?> students from Class <?php echo htmlspecialchars($filter_class); ?></p>
            <?php endif; ?>
        </center>  
    </div>    

    <?php if($filter_class): ?>
    <div class="id-container">
        <?php foreach ($filteredStudents as $student): ?>
        <div class="id-card">
            <center>
                <table width='98%' border='0'>
                    <tr>
                        <td> <img src="https://i.postimg.cc/Bnnsb9f4/200x200.png" height="90px" width="80px"> </td> 
                        <td align="center" width="35%"><h3><center>
                        শিক্ষা স্কুল অ্যান্ড কলেজ, রাজশাহী<br>
                        প্রবেশপত্র
                        </center></h3></td> 
                        <td align="right"><img src='https://www.sscraj.com/cv/files/files/St-img/2025/<?php echo htmlspecialchars($student['class']); ?>/<?php echo htmlspecialchars($student['roll']); ?>.jpg' height='90px' width='90px' style="border:1px solid black;"></td>  
                    </tr>
                </table>
            </center>

            <center>
                <table width='98%' border='0'>
                    <tr>
                        <td width='13%'> পরীক্ষার্থীর নাম </td> 
                        <td width='4%'>:</td> 
                        <td width='30%'><b><?php echo htmlspecialchars($student['name_bangla']); ?></b></td> 
                        <td>&nbsp;</td> 
                        <td width='8%'>শ্রেণি</td>
						<td width='2%'>:</td> 						
                        <td><?php echo convertToBanglaClass($class);?></td> 
                    </tr>

                    <tr>
                        <td> পিতার নাম </td> 
                        <td>:</td> 
                        <td><?php echo htmlspecialchars($student['father_name_bangla']); ?></td> 
                        <td>&nbsp;</td> 
                        <td width='8%'>শাখা</td> 
						<td width='4%'>:</td> 
                        <td>লাল</td> 
                    </tr>

                    <tr>
                        <td> মাতার নাম </td> 
                        <td>:</td> 
                        <td><?php echo htmlspecialchars($student['mother_name_bangla']); ?></td> 
                        <td>&nbsp;</td> 
                        <td>আইডি</td> 
						<td width='4%'>:</td> 
                        <td><?php echo htmlspecialchars($student['bio_id']); ?></td> 
                    </tr>
                </table>
              
<table width="98%">
<tr>
<td width="50%">
<table width="98%" border="1">
<tr align="center">
<td><b>মূল্যায়ণের নাম</b>
</td>
<td><b>মূল্যায়ণের সময়</b>
</td>
</tr>
<tr align="center">
<td height="70px"> প্রাক-নির্বাচনি পরীক্ষা ২০২৫
</td>
<td>সকাল ৮.৩০ টা-বেলা ১১.৩০
</td>
</tr>
</table>
</td>
<td width="45%">
<table width="98%" border="1">
<tr>
<td><center><b>নিয়ন্ত্রকের স্বাক্ষর</b></center>
</td>
</tr>
<tr>
<td height="70px">
</td>
</tr>
</table>
</td>
</tr>
</table>
<br>

            </center>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</body>
</html>