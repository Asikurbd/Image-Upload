<?php

require_once 'auth.php';
redirect_if_not_logged_in();

// Load students from file
$students = [];
if (file_exists('students.json')) {
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Change Filtering ###
$filter_class = $_GET['class'] ?? '';
$filter_name = $_GET['name'] ?? '';
$filter_section = $_GET['section'] ?? '';
$filter_father_name_bangla = $_GET['father_name_bangla'] ?? '';
$filter_gender = $_GET['gender'] ?? '';
$filter_group = $_GET['group'] ?? '';
$filter_roll = $_GET['roll'] ?? '';

// Bangla number conversion
function en2bnNumber($number) {
    $bangla_numbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    $english_numbers = range(0, 9);
    return str_replace($english_numbers, $bangla_numbers, $number);
}


// Change Filtering ###
$filteredStudents = array_filter($students, function($student) use ($filter_class, $filter_name, $filter_section, $filter_gender, $filter_group, $filter_father_name_bangla, $filter_roll) {
	
	
    return (empty($filter_class) || stripos($student['class'], $filter_class) !== false) &&
           (empty($filter_name) || stripos($student['name_english'], $filter_name) !== false || 
                                 stripos($student['name_bangla'], $filter_name) !== false) &&
           (empty($filter_section) || stripos($student['section'], $filter_section) !== false) &&
           (empty($filter_gender) || stripos($student['gender'], $filter_gender) !== false) &&
           (empty($filter_group) || stripos($student['group'], $filter_group) !== false) &&
		   (empty($filter_father_name_bangla) || stripos($student['father_name_bangla'], $filter_father_name_bangla) !== false) &&
           (empty($filter_roll) || stripos($student['roll'], $filter_roll) !== false);
});


$totalStudents = count($filteredStudents);

// Group by class and calculate statistics
$studentsByClass = [];
$classStatistics = [];

foreach ($filteredStudents as $student) {
    $class = $student['class'];
    if (!isset($studentsByClass[$class])) {
        $studentsByClass[$class] = [];
        $classStatistics[$class] = [
            'total' => 0,
            'male' => 0,
            'female' => 0,
            'groups' => []
        ];
    }
    $studentsByClass[$class][] = $student;
    
    // Update statistics
    $classStatistics[$class]['total']++;
    if (stripos($student['gender'], '*Male') !== false) {
        $classStatistics[$class]['male']++;
    } else {
        $classStatistics[$class]['female']++;
    }
    
    // Group count
    $group = $student['group'] ?? 'None';
    if (!isset($classStatistics[$class]['groups'][$group])) {
        $classStatistics[$class]['groups'][$group] = 0;
    }
    $classStatistics[$class]['groups'][$group]++;
}

// Sort classes
ksort($studentsByClass);
?>

<!DOCTYPE html>
<html>
<head>
<link href='style.css' rel='stylesheet' type='text/css'/>
<link href='https://asikurbd.github.io/wi/admn3.png' rel='icon' type='image/x-icon'/>
    <title>Management System</title>

</head>
<body>
    <center>    
        <h1>
        <div style="background:#e1e1e1;"> 
        <a href="index.php"><font color="black">Teacher & Student Management System</a></font>
        </div>
        </h1>
            
    

 <br><center>Total Students in School: <b>
 <font color="red"><?php echo $totalStudents; ?> </font></b> </center>
	<br><br>
<?php foreach ($studentsByClass as $class => $classStudents): ?>
       
<table width="80%" border="0">
<tr>
<td>
<?php echo htmlspecialchars($class); ?></b>
</td>
<td>
Total= <b><?php echo $classStatistics[$class]['total']; ?></b>
</td>
<td>
Boys= <?php echo $classStatistics[$class]['male']; ?>
</td>
<td>
Girls= <?php echo $classStatistics[$class]['female']; ?>
</td>
<td width="40%">
Groups= <?php foreach ($classStatistics[$class]['groups'] as $group => $count): ?> 
<?php echo htmlspecialchars($group) ?>: <?php echo $count; ?>
<?php endforeach; ?>
</td>
</tr>
</table>
        
<style>
table {
  table-layout: fixed;
}
</style>        
    
		
    <?php endforeach; ?>
    <br>    
    <center><a href="logout.php">Logout</a></center>
    <br>
</body>
</html>