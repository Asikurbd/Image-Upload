
<!DOCTYPE html>
<html>
<head>


<link href='https://asikurbd.github.io/wi/admn3.png' rel='icon' type='image/x-icon'/>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-box { width: 800px; padding: 20px; border: 1px solid #ddd; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .error { color: red; margin-bottom: 15px; }
        input { width: 100%; padding: 8px; margin: 8px 0; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px; border: none; width: 100%; cursor: pointer; }
        button:hover { background-color: #45a049; }
    </style>

    <title>Success</title>
</head>
<body>
    <div class="login-box">
        <h2><center>আপনার আবেদনটি সফলভাবে গ্রহণ করা হয়েছে। ধন্যবাদ।</center></h2>        
    </div>
</body>
</html>