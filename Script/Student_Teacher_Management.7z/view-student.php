<?php
// Load students
$students = [];
if (file_exists('students.json')) 

{
    $students = json_decode(file_get_contents('students.json'), true) ?: [];
}

// Find student by ID
$student = null;
$studentId = $_GET['id'] ?? null;

foreach ($students as $key => $s) {
    if ($s['id'] == $studentId) {
        $student = $s;
        $studentKey = $key;
        break;
    }
}

if (!$student) {
    header('Location: index.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $students[$studentKey] = [
        'id' => $student['id'],
        'roll' => $_POST['roll'],
        'class' => $_POST['class'],
		'bio_id' => $_POST['bio_id'],
		'group' => $_POST['group'],
        'section' => $_POST['section'],
        'name_bangla' => $_POST['name_bangla'],
        'name_english' => $_POST['name_english'],
        'dob' => $_POST['dob'],
        'birth_certificate' => $_POST['birth_certificate'],
        'mobile' => $_POST['mobile'],
        'gender' => $_POST['gender'],
        'blood_group' => $_POST['blood_group'],
        'father_name_bangla' => $_POST['father_name_bangla'],
        'father_name_english' => $_POST['father_name_english'],
        'father_dob' => $_POST['father_dob'],
        'father_nid' => $_POST['father_nid'],
        'mother_name_bangla' => $_POST['mother_name_bangla'],
        'mother_name_english' => $_POST['mother_name_english'],
        'mother_dob' => $_POST['mother_dob'],
        'mother_nid' => $_POST['mother_nid'],
		'present_address' => $_POST['present_address'],
		'permanent_paddress' => $_POST['permanent_paddress'],
		'photo' => $_POST['photo'],
		'sign' => $_POST['sign'],
		'rel' => $_POST['rel'],
    ];
    
    // Save to file
    file_put_contents('students.json', json_encode($students));
    
    // Redirect to list
    header('Location: index.php');
    exit;
}
?>



<head>
  	<meta charset="utf-8" />
   	<title>View</title>
  	<link rel="stylesheet" href="style.css" />
  	<link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>

<html>
  

<form method="post">
                
<table width='100%' border='1'>
 
<tr>
<td> 

Serial

</td> <td align='center' width='5%'>:</td>
<td> 

 <?php echo htmlspecialchars($student['roll']); ?>
 
<td align='center'><b>Photo</b></td>
</td></tr>

<tr>

<td width='25%'> Class </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($student['class']); ?>

</td>

<td rowspan='7' align='center'>

<a href='https://www.sscraj.com/cv/files/files/St-img/2025/<?php echo htmlspecialchars($student['class']); ?>/<?php echo htmlspecialchars($student['roll']); ?>.jpg'><img src='https://www.sscraj.com/cv/files/files/St-img/2025/<?php echo htmlspecialchars($student['class']); ?>/<?php echo htmlspecialchars($student['roll']); ?>.jpg' height='169px' width='169px'/></a> <br>
<a href='<?php echo htmlspecialchars($student['sign']); ?>'><img src='<?php echo htmlspecialchars($student['sign']); ?>' height='40px' width='169x'/></a>  

</td>
</tr>

<tr><td> Section </td> 
<td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($student['section']); ?>

</td>
</tr>

<tr><td width='15%'> Full Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($student['name_english']); ?>

</td>
</tr>

<tr><td width='15%'> সম্পূর্ণ নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<b><?php echo htmlspecialchars($student['name_bangla']); ?></b>

</td>
</tr>

<tr><td width='15%'> Date Of Birth </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($student['dob']); ?>

</td>
</tr>

<tr><td width='15%'> Birth Certificate No </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($student['birth_certificate']); ?>

</td>
</tr>

<tr><td width='15%'> Mobile Number </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<b><?php echo htmlspecialchars($student['mobile']); ?></b>

</td>
</tr>

<tr><td width='15%'> Student ID </td> <td align='center' width='5%'>:</td><td colspan='2'> 

<?php echo htmlspecialchars($student['bio_id']); ?>

</td>
</tr>

<tr><td width='15%'> Gender </td> <td align='center' width='5%'>:</td><td colspan='2'> 

<?php echo htmlspecialchars($student['gender']); ?>

</td></tr>

<tr><td width='15%'> Group </td> <td align='center' width='5%'>:</td><td colspan='2'> 

<?php echo htmlspecialchars($student['group']); ?>

</td></tr>

<tr><td width='15%'> Blood Group </td> <td align='center' width='5%'>:</td><td colspan='2'> 

<?php echo htmlspecialchars($student['blood_group']); ?>

</td>
</tr>

<tr><td width='15%' calspan='2'> ধর্ম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
<?php echo htmlspecialchars($student['rel']); ?>
  
</td>
</tr>

<tr><td width='15%'> বর্তমান ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['present_address']); ?>

</td>
</tr>

<tr><td width='15%'> স্থায়ী ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['permanent_paddress']); ?>

</td>
</tr>

<tr><td width='15%'> Father's Name (English)</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['father_name_english']); ?>

</td>
</tr>

<tr><td width='15%'> পিতার নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['father_name_bangla']); ?>

</td>
</tr>

<tr><td width='15%'> Father's Date of Birth</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<?php echo htmlspecialchars($student['father_dob']); ?>
  
</td>
</tr>

<tr><td width='15%'>Father's NID No </td> <td align='center' width='5%'>:</td>
<td colspan='3'> 

<?php echo htmlspecialchars($student['father_nid']); ?>

</td>
</tr>

<tr><td width='15%'>Mother's Name (English)</td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['mother_name_english']); ?>

</td>
</tr>

<tr><td width='15%'> মাতার নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['mother_name_bangla']); ?>

</td>
</tr>

<tr><td width='15%'> Mother's Date of Birth </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($student['mother_dob']); ?>

</td>
</tr>

<!-- copy this table -->
<tr><td width='15%'> Mother's NID No </td> <td align='center' width='5%'>:</td><td colspan='2'>  

<?php echo htmlspecialchars($student['mother_nid']); ?>

</td></tr>   
<!-- end copy this table -->   

</table>
                 
</form>
<br>
<a href="delete-student.php?id=<?php echo $student['id']; ?>" onclick="return confirm('Are you sure?')"><img src="https://asikurbd.github.io/wi/ddd.png"/></a>
</html>

