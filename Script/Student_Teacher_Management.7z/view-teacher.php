<?php
// Load teachers data

date_default_timezone_set('Asia/Dhaka');
$currentDateTime = date('d-m-Y h:i:s A');

$teacherDatas = [];
if (file_exists('teachers.json')) {
    $teacherDatas = json_decode(file_get_contents('teachers.json'), true) ?: [];
}

// Find teacher by ID
$teacherData = null;
$teacherDataId = $_GET['id'] ?? null;
$teacherDataKey = null;

foreach ($teacherDatas as $key => $t) {
    if ($t['id'] == $teacherDataId) {
        $teacherData = $t;
        $teacherDataKey = $key;
        break;
    }
}

if (!$teacherData) {
    header('Location: index.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update teacher data
    $teacherDatas[$teacherDataKey] = [
        'id' => $teacherData['id'],
		
        'post' => $_POST['post'],
        'name' => $_POST['name'],
		'ename' => $_POST['ename'],
		'fname' => $_POST['fname'],
		'fename' => $_POST['fename'],
		'mname' => $_POST['mname'],
		'mename' => $_POST['mename'],
		'dob' => $_POST['dob'],
		'pob' => $_POST['pob'],
		'gen' => $_POST['gen'],
		'nat' => $_POST['nat'],
		'brn' => $_POST['brn'],
		'nid' => $_POST['nid'],
		'pid' => $_POST['pid'],
		'rel' => $_POST['rel'],
		'pad' => $_POST['pad'],
		'pead' => $_POST['pead'],
		'mob' => $_POST['mob'],
		'email' => $_POST['email'],
		'mar' => $_POST['mar'],
		'xm' => $_POST['xm'],
		'res' => $_POST['res'],
		'brd' => $_POST['brd'],
		'grp' => $_POST['grp'],
		'rl' => $_POST['rl'],
		'py' => $_POST['py'],
		'att' => $_POST['att'],
		'pp' => $_POST['pp'],
		'blood' => $_POST['blood'],
		'xm2' => $_POST['xm2'],
		'res2' => $_POST['res2'],
		'brd2' => $_POST['brd2'],
		'grp2' => $_POST['grp2'],
		'rl2' => $_POST['rl2'],
		'py2' => $_POST['py2'],
		'xm3' => $_POST['xm3'],
		'res3' => $_POST['res3'],
		'sub' => $_POST['sub'],
		'crs' => $_POST['crs'],
		'uni' => $_POST['uni'],
		'py3' => $_POST['py3'],
		'xm4' => $_POST['xm4'],
		'res4' => $_POST['res4'],
		'sub2' => $_POST['sub2'],
		'crs2' => $_POST['crs2'],
		'uni2' => $_POST['uni2'],
		'py4' => $_POST['py4'],
		'photo' => $_POST['photo'],
		'sign' => $_POST['sign'],
		'bisoy' => $_POST['bisoy'],
		'husb' => $_POST['husb'],
		'huse' => $_POST['huse'],
		'hbirth' => $_POST['hbirth'],
		'hnid' => $_POST['hnid'],
		'hwork' => $_POST['hwork'],
		'fbirth' => $_POST['fbirth'],
		'fdead' => $_POST['fdead'],
		'fnid' => $_POST['fnid'],
		'fwork' => $_POST['fwork'],
		'mbirth' => $_POST['mbirth'],
		'mdead' => $_POST['mdead'],
		'mnid' => $_POST['mnid'],
		'mwork' => $_POST['mwork'],
		'cnam' => $_POST['cnam'],
		'cname' => $_POST['cname'],
		'cbirth' => $_POST['cbirth'],
		'cnid' => $_POST['cnid'],
		'cwork' => $_POST['cwork'],
		'rg1' => $_POST['rg1'],
		'rg2' => $_POST['rg2'],
		'rg3' => $_POST['rg3'],
		'rg4' => $_POST['rg4'],
		'#' => $_POST['#'],
		'#' => $_POST['#'],
		
    ];
    
    // Save to file
    file_put_contents('teachers.json', json_encode($teacherDatas, JSON_PRETTY_PRINT));
    
    // Redirect to view page
    header("Location: view-teacher.php?id={$teacherData['id']}");
    exit;
}
?>



<head>
  	<meta charset="utf-8" />
   	<title>View Teachers</title>
  	<link rel="stylesheet" href="style.css" />
  	<link rel="icon" href="https://asikurbd.github.io/wi/admn3.png">
</head>

<html>
  
  
<form method="post">
                
<table width='100%' border='1'>
 
<tr>
<td> পদবী </td> <td align='center' width='5%'>:</td>
<td> 

<?php echo htmlspecialchars($teacherData['post']); ?>  
  
<td align='center'><b>Photo</b></td>
</td></tr>

<tr>

<td width='25%'> নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['name']); ?>

</td>

<td rowspan='8' align='center'>
<a href='<?php echo htmlspecialchars($teacherData['photo']); ?>'><img src='<?php echo htmlspecialchars($teacherData['photo']); ?>' height='175px' width='175px'/></a> <br>
<a href='<?php echo htmlspecialchars($teacherData['sign']); ?>'><img src='<?php echo htmlspecialchars($teacherData['sign']); ?>' height='40px' width='175px'/></a>  
</td>
</tr>

<tr><td> Name </td> 
<td align='center' width='5%'>:</td>
<td width='48%'> 
<?php echo htmlspecialchars($teacherData['ename']); ?>

</td>
</tr>

<tr><td width='15%'> পিতার নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['fname']); ?>

</td>
</tr>

<tr><td width='15%'> Father's Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['fename']); ?>

</td>
</tr>

<tr><td width='15%'> মাতার নাম </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['mname']); ?>

</td>
</tr>

<tr><td width='15%'> Mother's Name </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['mename']); ?>

</td>
</tr>

<tr><td width='15%'> জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['dob']); ?>

</td>
</tr>

<tr><td width='15%'> জন্ম স্থান (জেলা) </td> <td align='center' width='5%'>:</td>
<td width='48%'> 

<?php echo htmlspecialchars($teacherData['pob']); ?>

</td>
</tr>

<tr><td width='15%'> বিষয় </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['bisoy']); ?>

</td>
</tr>

<tr><td width='15%' calspan='2'> লিঙ্গ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<?php echo htmlspecialchars($teacherData['gen']); ?>
  
</td>
</tr>

<tr><td width='15%'> জাতীয়তা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['nat']); ?>

</td>
</tr>

<tr><td width='15%'> জন্মনিবন্ধন নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['brn']); ?>

</td>
</tr>

<tr><td width='15%'> NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['nid']); ?>

</td>
</tr>

<tr><td width='15%'> পাসপোর্ট নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['pid']); ?>

</td>
</tr>

<tr><td width='15%'> ধর্ম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<?php echo htmlspecialchars($teacherData['rel']); ?>
  
</td>
</tr>

<tr><td width='15%'>সম্পূর্ণ বর্তমান ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='3'> 

<?php echo htmlspecialchars($teacherData['pad']); ?>

</td>
</tr>

<tr><td width='15%'>সম্পূর্ণ স্থায়ী ঠিকানা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['pead']); ?>

</td>
</tr>

<tr><td width='15%'> মোবাইল নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['mob']); ?>

</td>
</tr>

<tr><td width='15%'> ই-মেইল </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['email']); ?>

</td>
</tr>

<tr><td width='15%'> রক্তের গ্রুপ </td> <td align='center' width='5%'>:</td>
<td colspan='2'>   
<?php echo htmlspecialchars($teacherData['blood']); ?>
  </td>
</tr>   
   
<tr><td width='15%'> বৈবাহিক অবস্থা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
  
<?php echo htmlspecialchars($teacherData['mar']); ?>
  
  </td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['husb']); ?>

</td>
</tr>

<tr><td width='15%'> Husband/Wife Name </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['huse']); ?>

</td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['hbirth']); ?>

</td>
</tr>


<tr><td width='15%'> স্বামী/স্ত্রীর NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['hnid']); ?>

</td>
</tr>

<tr><td width='15%'> স্বামী/স্ত্রীর পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['hwork']); ?>

</td>
</tr>

<tr><td width='15%'> পিতার জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['fbirth']); ?>

</td>
</tr>

<tr><td width='15%'> পিতা কি মৃত ? </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 
<?php echo htmlspecialchars($teacherData['fdead']); ?>
</td>
</tr>

<tr><td width='15%'> পিতার NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['fnid']); ?>

</td>
</tr>

<tr><td width='15%'> পিতার পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['fwork']); ?>

</td>
</tr>

<tr><td width='15%'> মাতার জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['mbirth']); ?>

</td>
</tr>

<tr><td width='15%'> মাতা কি মৃত ? </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['mdead']); ?>

</td>
</tr>

<tr><td width='15%'> মাতার NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['mnid']); ?>

</td>
</tr>

<tr><td width='15%'> মাতার পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['mwork']); ?>

</td>
</tr>

<tr><td width='15%'> আপনার ১ম সন্তানের নাম </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['cnam']); ?>

</td>
</tr>

<tr><td width='15%'> Your 1st Child Name </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['cname']); ?>

</td>
</tr>

<tr><td width='15%'> ১ম সন্তানের জন্ম তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['cbirth']); ?>

</td>
</tr>


<tr><td width='15%'>  ১ম সন্তানের BirthID/NID নম্বর </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['cnid']); ?>

</td>
</tr>

<tr><td width='15%'> ১ম সন্তানের পেশা </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['cwork']); ?>

</td>
</tr>

<tr><td width='15%'> প্রথম যোগদানের তারিখ </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['att']); ?>

</td>
</tr>
   
<tr><td width='15%'> প্রশিক্ষণের তথ্য (যদি থাকে) </td> <td align='center' width='5%'>:</td>
<td colspan='2'> 

<?php echo htmlspecialchars($teacherData['pp']); ?>

</td>
</tr>

</table>

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>

<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> SSC or Equivalent Level 
</tr>

<tr align='center'>
<td width="30%">Examination Name 
<hr>

<?php echo htmlspecialchars($teacherData['xm']); ?> &nbsp;
<hr>
Result 
<hr>
<?php echo htmlspecialchars($teacherData['res']); ?> &nbsp;

</td> 
<td width="30%">

Board
<hr>

<?php echo htmlspecialchars($teacherData['brd']); ?> &nbsp;
<hr>
Group/Subject
<hr>
<?php echo htmlspecialchars($teacherData['grp']); ?> &nbsp;

</td> 
<td width="30%">

Roll Number

<hr>

<?php echo htmlspecialchars($teacherData['rl']); ?> &nbsp;
<hr>
Passing Year 
<hr>
<?php echo htmlspecialchars($teacherData['py']); ?> &nbsp;

</td></tr></table>

<center>SSC Registration Number: <?php echo htmlspecialchars($teacherData['rg1']); ?> &nbsp;
</center> 

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>

<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> 

HSC or Equivalent Level 
</tr>
<tr align='center'>
<td width="30%">Examination Name 
<hr>

<?php echo htmlspecialchars($teacherData['xm2']); ?> &nbsp;
<hr>
Result 
<hr>
<?php echo htmlspecialchars($teacherData['res2']); ?> &nbsp;
</td> 
<td width="30%">

Board
<hr>
<?php echo htmlspecialchars($teacherData['brd2']); ?> &nbsp;
<hr>
Group/Subject

<hr>
<?php echo htmlspecialchars($teacherData['grp2']); ?> &nbsp;

</td> 
<td width="30%">
Roll Number

<hr>
<?php echo htmlspecialchars($teacherData['rl2']); ?> &nbsp;
<hr>
Passing Year
 <hr>
<?php echo htmlspecialchars($teacherData['py2']); ?> &nbsp;

</td></tr></table>
<center> HSC Registration Number: <?php echo htmlspecialchars($teacherData['rg2']); ?> &nbsp;
</center> 

<!-- _______________________________ -->
<br>

<table width='100%' border='1'>
<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> Graduation or Equivalent Level  
</tr>
<tr align='center'>
<td width="30%">

Examination Name 

<hr>

<?php echo htmlspecialchars($teacherData['xm3']); ?> &nbsp;
<hr>
Result 
<hr>
<?php echo htmlspecialchars($teacherData['res3']); ?> &nbsp;
</td> 

<td width="30%">

Subject/Degree
<hr>
<?php echo htmlspecialchars($teacherData['sub']); ?> &nbsp;
<hr>
Course Duration 
<hr>
<?php echo htmlspecialchars($teacherData['crs']); ?> &nbsp;

</td> 
<td width="30%">

University/Institute 
<hr>
<?php echo htmlspecialchars($teacherData['uni']); ?> &nbsp;
<hr>
 Passing Year
<hr>
<?php echo htmlspecialchars($teacherData['py3']); ?> &nbsp;
</td></tr></table>
<center>Honours Registration Number: <?php echo htmlspecialchars($teacherData['rg3']); ?>
</center> 

<br>

<!-- _______________________________ -->

<table width='100%' border='1'>
<tr bgcolor='#e7e7e7'><td colspan='3' align='center'> Masters or Equivalent Level   
</tr>
<tr align='center'>
<td width="30%">

Examination Name 
<hr>
<?php echo htmlspecialchars($teacherData['xm4']); ?> &nbsp;
<hr>
Result 
<hr>
<?php echo htmlspecialchars($teacherData['res4']); ?> &nbsp;

</td> 
<td width="30%">

Subject/Degree
<hr>
<?php echo htmlspecialchars($teacherData['sub2']); ?> &nbsp;
<hr>
Course Duration 
<hr>
<?php echo htmlspecialchars($teacherData['crs2']); ?> &nbsp;
</td> 
<td width="30%">
University/Institute 
<hr>
<?php echo htmlspecialchars($teacherData['uni2']); ?> &nbsp;
<hr>
Passing Year 
<hr>
<?php echo htmlspecialchars($teacherData['py4']); ?> &nbsp;
</td></tr></table>
<center>Masters Registration Number: <?php echo htmlspecialchars($teacherData['rg4']); ?>
</center> 
  <br>                  
</form>

</html>

