<?php include 'password.php';?>


<?php
// Define the data file
$dataFile = 'links.json';

// Initialize the links array
$links = [];

// Load existing links from file
if (file_exists($dataFile)) {
    $links = json_decode(file_get_contents($dataFile), true) ?: [];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        // Delete a link
        $id = $_POST['id'];
        if (isset($links[$id])) {
            unset($links[$id]);
            file_put_contents($dataFile, json_encode(array_values($links)));
            $message = "Link deleted successfully!";
        }
    } elseif (isset($_POST['id']) && $_POST['id'] !== '') {
        // Update an existing link
        $id = $_POST['id'];
        if (isset($links[$id])) {
            $links[$id] = [
                'name' => htmlspecialchars(trim($_POST['name'])),
                'url' => htmlspecialchars(trim($_POST['url'])),
                'timestamp' => time() // Add timestamp when updating
            ];
            file_put_contents($dataFile, json_encode($links));
            $message = "Link updated successfully!";
        }
    } else {
        // Add a new link to the beginning of the array
        array_unshift($links, [
            'name' => htmlspecialchars(trim($_POST['name'])),
            'url' => htmlspecialchars(trim($_POST['url'])),
            'timestamp' => time() // Add timestamp
        ]);
        file_put_contents($dataFile, json_encode($links));
        $message = "Link added successfully!";
    }
    
    // Redirect to avoid form resubmission
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle edit request
$editId = null;
$editLink = ['name' => '', 'url' => ''];
if (isset($_GET['edit'])) {
    $editId = $_GET['edit'];
    if (isset($links[$editId])) {
        $editLink = $links[$editId];
    }
}

// No need to sort since new items are added to beginning
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href='https://asikurbd.github.io/wi/sat2.png' rel='icon' type='image/x-icon'/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL Link Saver</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 5px; }
        .container { background: #f9f9f9; padding: 5px; border-radius: 5px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="url"] { width: 100%; padding: 6px; box-sizing: border-box; }
        button { background: #4CAF50; color: white; border: none; padding: 10px 15px; cursor: pointer; }
        button:hover { background: #45a049; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f2f2f2; }
		tr:nth-child(even) {background-color: #f0f1f2}
        .actions a { margin-right: 10px; text-decoration: none; }
        .edit { color: #2196F3; }
        .delete { color: #f44336; }
        .message { padding: 10px; background: #dff0d8; color: #3c763d; margin-bottom: 15px; border-radius: 4px; }
a {
	text-decoration: none; 
	color: #991a22;
}

a:hover { 
  	color: red;
 }
    </style>
</head>
<body>
    <div class="container">
        
        <?php if (isset($_GET['message'])): ?>
            <div class="message"><?php echo htmlspecialchars($_GET['message']); ?></div>
        <?php endif; ?>
        
        <h3><?php echo $editId !== null ? 'Edit Link' : ''; ?></h3>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $editId !== null ? $editId : ''; ?>">
            
            <div class="form-group">
                <label for="name">Link Name:</label>
                <input type="text" id="name" name="name" required 
                       value="<?php echo htmlspecialchars($editLink['name']); ?>">
            </div>
            
            <div class="form-group">
                <label for="url">URL:</label>
                <input type="url" id="url" name="url" required 
                       value="<?php echo htmlspecialchars($editLink['url']); ?>">
            </div>
            
            <button type="submit"><?php echo $editId !== null ? 'Update Link' : 'Save Link'; ?></button>
            
            <?php if ($editId !== null): ?>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>">Cancel</a>
            <?php endif; ?>
        </form>
        
        <b><center><a href="index.php">Saved Links</a></center></b>
        <?php if (empty($links)): ?>
            <p>No links saved yet.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Link</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($links as $id => $link): ?>
                        <tr>
                            <td>
                                <img src="https://asikurbd.github.io/wi/r4.png"/> 
                                <a href="<?php echo htmlspecialchars($link['url']); ?>" target="_blank"><?php echo htmlspecialchars($link['name']); ?></a>
                            </td>
                            <td class="actions">
                                <a href="?edit=<?php echo $id; ?>" class="edit">Edit</a>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                                    <input type="hidden" name="delete" value="1">
                                    <a href="#" onclick="if(confirm('Are you sure you want to delete this link?')) { this.parentNode.submit(); }" class="delete">Delete</a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<br>
<hr>
<center><a href="?logout=1">Logout</a></center><br><br>
</body>
</html>

