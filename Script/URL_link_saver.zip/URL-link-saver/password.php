<?php
// ===== CONFIGURATION ===== //
$PASSWORD = "2255"; // Set your password here (change this)
$PAGE_TITLE = "Protected Page"; // Change this to your page title
// ===== END CONFIGURATION ===== //

session_start();

// Create a unique session key based on the current page
$session_key = 'authenticated_' . md5($_SERVER['PHP_SELF']);

// Check if password is correct when form is submitted
if (isset($_POST['password'])) {
    if ($_POST['password'] === $PASSWORD) {
        $_SESSION[$session_key] = true;
    } else {
        $error = "Wrong password!";
    }
}

// Check if user is already authenticated for this specific page
$authenticated = isset($_SESSION[$session_key]) && $_SESSION[$session_key] === true;

// Logout functionality - only for this page
if (isset($_GET['logout'])) {
    unset($_SESSION[$session_key]); // Only unset this page's authentication
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// If not authenticated, show login form
if (!$authenticated) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <link href='https://asikurbd.github.io/wi/lk1.png' rel='icon' type='image/x-icon'/>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Required</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }
            .login-box { background: white; padding: 30px; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); width: 300px; text-align: center; }
            h1 { margin-top: 0; color: #333; }
            input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; border: 1px solid #ddd; border-radius: 3px; }
            button { background: #4CAF50; color: white; border: none; padding: 10px 15px; border-radius: 3px; cursor: pointer; width: 100%; }
            button:hover { background: #45a049; }
            .error { color: red; margin: 10px 0; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h1>Login Required</h1>
            <?php if (isset($error)) echo '<div class="error">'.$error.'</div>'; ?>
            <form method="POST">
                <input type="password" name="password" placeholder="Enter password" required>
                <button type="submit">Login</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>

<!-- ===== YOUR PROTECTED CONTENT STARTS HERE ===== -->



