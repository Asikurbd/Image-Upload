<?php
session_start();

// File to store scores
$scoreFile = 'scores.txt';

// List of words to match
$wordList = [


'আম', 'কলা', 'জাম', 'লিচু', 'কাঁঠাল', 'আনারস', 'পেঁপে', 'তরমুজ', 'আঙুর', 'মাল্টা', 'পেয়ারা', 'কমলা', 'লেবু', 'আমড়া', 'কুল', 'বরই', 'আতা', 'সফেদা', 'নারিকেল', 'খেজুর', 'তাল', 'বেল', 'চালতা', 'কামরাঙা', 'স্ট্রবেরি', 'ব্লুবেরি', 'রাস্পবেরি', 'ব্ল্যাকবেরি', 'ক্র্যানবেরি', 'গোজবেরি', 'ড্রাগনফ্রুট', 'প্যাসনফ্রুট', 'কিউই', 'অ্যাভোকাডো', 'পিচ', 'প্লাম', 'এপ্রিকট', 'নেক্টারিন', 'ল্যাংকাট', 'লংগান', 'রাম্বুটান', 'ম্যাঙ্গোস্টিন', 'পমেলো', 'জাম্বুরা', 'কুমকোয়াত', 'ফিগ', 'অলিভ', 'ডেট', 'প্রুন', 'গ্রেপ', 'কারেন্ট', 'রাইসিন', 'ক্র্যানবেরি', 'ব্ল্যাককারেন্ট', 'রেডকারেন্ট', 'হোয়াইটকারেন্ট', 'গোলাপজাম', 'কদবেল', 'কাঠাল', 'আমলকী', 'হরীতকী', 'বয়ড়া', 'নিম', 'অর্জুন', 'শিশু', 'পাতা', 'ফুল', 'ডাল', 'শাখা', 'কাণ্ড', 'মূল', 'বীজ', 'মাটি', 'পানি', 'বাতাস', 'আগুন', 'ধোঁয়া', 'বরফ', 'বৃষ্টি', 'ঝড়', 'বাদল', 'হিম', 'তুষার', 'কুয়াশা', 'শিশির', 'ঊষা', 'সন্ধ্যা', 'সকাল', 'দুপুর', 'বিকাল', 'রাত', 'ভোর', 'গোধূলি', 'চাঁদ', 'সূর্য', 'তারা', 'গ্রহ', 'নক্ষত্র', 'মহাকাশ', 'আকাশ', 'মেঘ', 'রংধনু', 'বিদ্যুৎ', 'বজ্র', 'মেঘলা', 'রোদ', 'ছায়া', 'আলো', 'অন্ধকার', 'জল', 'স্থল', 'পর্বত', 'পাহাড়', 'টিলা', 'মরুভূমি', 'মাঠ', 'জঙ্গল', 'বন', 'গ্রাম', 'শহর', 'নগর', 'মহানগর', 'রাজধানী', 'দেশ', 'বিদেশ', 'মহাদেশ', 'সমুদ্র', 'নদী', 'খাল', 'বিল', 'হ্রদ', 'পুকুর', 'ডোবা', 'সাগর', 'মহাসাগর', 'প্রান্তর', 'মরুদ্যান', 'সৈকত', 'বালি', 'পাথর', 'নুড়ি', 'কঙ্কর', 'মাটি', 'কাদা', 'ধুলো', 'বালুকরা', 'শিলা', 'গ্রানাইট', 'বেসাল্ট', 'চুনাপাথর', 'বল্ডার', 'পাহাড়ি', 'পর্বতমালা', 'উপত্যকা', 'গিরিখাদ', 'ঝর্ণা', 'প্রপাত', 'জলপ্রপাত', 'ক্যানিয়ন', 'মালভূমি', 'টুন্ড্রা', 'তুন্দ্রা', 'সাভানা', 'গ্রাসল্যান্ড', 'চারণভূমি', 'ম্যানগ্রোভ', 'সুন্দরবন', 'পাতাগাছ', 'চিরসবুজ', 'পর্ণমোচী', 'গুল্ম', 'গুল্মজাতীয়', 'লতা', 'গুল্মলতা', 'বীরুৎ', 'ঘাস', 'শ্যাওলা', 'কাই', 'শৈবাল', 'ফার্ন', 'মস', 'হর্সটেল', 'অর্কিড', 'গোলাপ', 'গাঁদা', 'জবা', 'কৃষ্ণচূড়া', 'রাধাচূড়া', 'কাঞ্চন', 'পলাশ', 'শিমুল', 'শিরীষ', 'কদম', 'নাগেশ্বর', 'চাঁপা', 'বকুল', 'করবী', 'মল্লিকা', 'মালতী', 'যূথিকা', 'রজনীগন্ধা', 'গন্ধরাজ', 'টগর', 'দোলনচাঁপা', 'চামেলী', 'রঙ্গন', 'হাসনাহেনা', 'কাঠগোলাপ', 'নয়নতারা', 'চন্দ্রমল্লিকা', 'সূর্যমুখী', 'গ্লাডিওলাস', 'ডালিয়া', 'বাগানবিলাস', 'চন্দ্রমল্লিকা', 'জিনিয়া', 'পিটুনিয়া', 'মারিগোল্ড', 'ডেইজি', 'লিলি', 'টিউলিপ', 'ড্যাফোডিল', 'হাইসিন্থ', 'ক্রিস্যান্থেমাম', 'পপি', 'ল্যাভেন্ডার', 'আইরিস', 'অ্যাজালিয়া', 'বেগোনিয়া', 'হাইড্রেনজিয়া', 'ফ্লক্স', 'স্ন্যাপড্রাগন', 'প্যানসি', 'ভারবেনা', 'কসমস', 'পেটুনিয়া', 'স্যালভিয়া', 'স্টক', 'ভায়োলা', 'অ্যাস্টার', 'ক্যালেন্ডুলা', 'সেলোসিয়া', 'কোরিওপসিস', 'গেইলার্ডিয়া', 'হোলিহক', 'লুপিন', 'ন্যাস্তারটিয়াম', 'স্ক্যাবিওসা', 'স্ট্রবেরি', 'ব্লুবেরি', 'রাস্পবেরি', 'ব্ল্যাকবেরি', 'ক্র্যানবেরি', 'গোজবেরি', 'ড্রাগনফ্রুট', 'প্যাসনফ্রুট', 'কিউই', 'অ্যাভোকাডো', 'পিচ', 'প্লাম', 'এপ্রিকট', 'নেক্টারিন', 'ল্যাংকাট', 'লংগান', 'রাম্বুটান', 'ম্যাঙ্গোস্টিন', 'পমেলো', 'জাম্বুরা', 'কুমকোয়াত', 'ফিগ', 'অলিভ', 'ডেট', 'প্রুন', 'গ্রেপ', 'কারেন্ট', 'রাইসিন', 'ক্র্যানবেরি', 'ব্ল্যাককারেন্ট', 'রেডকারেন্ট', 'হোয়াইটকারেন্ট', 'গোলাপজাম', 'কদবেল', 'কাঠাল', 'আমলকী', 'হরীতকী', 'বয়ড়া', 'নিম', 'অর্জুন', 'শিশু', 'পাতা', 'ফুল', 'ডাল', 'শাখা', 'কাণ্ড', 'মূল', 'বীজ', 'মাটি', 'পানি', 'বাতাস', 'আগুন', 'ধোঁয়া', 'বরফ', 'বৃষ্টি', 'ঝড়', 'বাদল', 'হিম', 'তুষার', 'কুয়াশা', 'শিশির', 'ঊষা', 'সন্ধ্যা', 'সকাল', 'দুপুর', 'বিকাল', 'রাত', 'ভোর', 'গোধূলি', 'চাঁদ', 'সূর্য', 'তারা', 'গ্রহ', 'নক্ষত্র', 'মহাকাশ', 'আকাশ', 'মেঘ', 'রংধনু', 'বিদ্যুৎ', 'বজ্র', 'মেঘলা', 'রোদ', 'ছায়া', 'আলো', 'অন্ধকার', 'জল', 'স্থল', 'পর্বত', 'পাহাড়', 'টিলা', 'মরুভূমি', 'মাঠ', 'জঙ্গল', 'বন', 'গ্রাম', 'শহর', 'নগর', 'মহানগর', 'রাজধানী', 'দেশ', 'বিদেশ', 'মহাদেশ', 'সমুদ্র', 'নদী', 'খাল', 'বিল', 'হ্রদ', 'পুকুর', 'ডোবা', 'সাগর', 'মহাসাগর', 'প্রান্তর', 'মরুদ্যান', 'সৈকত', 'বালি', 'পাথর', 'নুড়ি', 'কঙ্কর', 'মাটি', 'কাদা', 'ধুলো', 'বালুকরা', 'শিলা', 'গ্রানাইট', 'বেসাল্ট', 'চুনাপাথর', 'বল্ডার', 'পাহাড়ি', 'পর্বতমালা', 'উপত্যকা', 'গিরিখাদ', 'ঝর্ণা', 'প্রপাত', 'জলপ্রপাত', 'ক্যানিয়ন', 'মালভূমি', 'টুন্ড্রা', 'তুন্দ্রা', 'সাভানা', 'গ্রাসল্যান্ড', 'চারণভূমি', 'ম্যানগ্রোভ', 'সুন্দরবন', 'পাতাগাছ', 'চিরসবুজ', 'পর্ণমোচী', 'গুল্ম', 'গুল্মজাতীয়', 'লতা', 'গুল্মলতা', 'বীরুৎ', 'ঘাস', 'শ্যাওলা', 'কাই', 'শৈবাল', 'ফার্ন', 'মস', 'হর্সটেল', 'অর্কিড', 'গোলাপ', 'গাঁদা', 'জবা', 'কৃষ্ণচূড়া', 'রাধাচূড়া', 'কাঞ্চন', 'পলাশ', 'শিমুল', 'শিরীষ', 'কদম', 'নাগেশ্বর', 'চাঁপা', 'বকুল', 'করবী', 'মল্লিকা', 'মালতী', 'যূথিকা', 'রজনীগন্ধা', 'গন্ধরাজ', 'টগর', 'দোলনচাঁপা', 'চামেলী', 'রঙ্গন', 'হাসনাহেনা', 'কাঠগোলাপ', 'নয়নতারা', 'চন্দ্রমল্লিকা', 'সূর্যমুখী', 'গ্লাডিওলাস', 'ডালিয়া', 'বাগানবিলাস', 'চন্দ্রমল্লিকা', 'জিনিয়া', 'পিটুনিয়া', 'মারিগোল্ড', 'ডেইজি', 'লিলি', 'টিউলিপ', 'ড্যাফোডিল', 'হাইসিন্থ', 'ক্রিস্যান্থেমাম', 'পপি', 'ল্যাভেন্ডার', 'আইরিস', 'অ্যাজালিয়া', 'বেগোনিয়া', 'হাইড্রেনজিয়া', 'ফ্লক্স', 'স্ন্যাপড্রাগন', 'প্যানসি', 'ভারবেনা', 'কসমস', 'পেটুনিয়া', 'স্যালভিয়া', 'স্টক', 'ভায়োলা', 'অ্যাস্টার', 'ক্যালেন্ডুলা', 'সেলোসিয়া', 'কোরিওপসিস', 'গেইলার্ডিয়া', 'হোলিহক', 'লুপিন', 'ন্যাস্তারটিয়াম', 'স্ক্যাবিওসা', 'স্ট্রবেরি', 'ব্লুবেরি', 'রাস্পবেরি', 'ব্ল্যাকবেরি', 'ক্র্যানবেরি', 'গোজবেরি', 'ড্রাগনফ্রুট', 'প্যাসনফ্রুট', 'কিউই', 'অ্যাভোকাডো', 'পিচ', 'প্লাম', 'এপ্রিকট', 'নেক্টারিন', 'ল্যাংকাট', 'লংগান', 'রাম্বুটান', 'ম্যাঙ্গোস্টিন', 'পমেলো', 'জাম্বুরা', 'কুমকোয়াত', 'ফিগ', 'অলিভ', 'ডেট', 'প্রুন', 'গ্রেপ', 'কারেন্ট', 'রাইসিন', 'ক্র্যানবেরি', 'ব্ল্যাককারেন্ট', 'রেডকারেন্ট', 'হোয়াইটকারেন্ট', 'গোলাপজাম', 'কদবেল', 'কাঠাল', 'আমলকী', 'হরীতকী', 'বয়ড়া', 'নিম', 'অর্জুন', 'শিশু', 'পাতা', 'ফুল', 'ডাল', 'শাখা', 'কাণ্ড', 'মূল', 'বীজ', 'মাটি', 'পানি', 'বাতাস', 'আগুন', 'ধোঁয়া', 'বরফ', 'বৃষ্টি', 'ঝড়', 'বাদল', 'হিম', 'তুষার', 'কুয়াশা', 'শিশির', 'ঊষা', 'সন্ধ্যা', 'সকাল', 'দুপুর', 'বিকাল', 'রাত', 'ভোর', 'গোধূলি', 'চাঁদ', 'সূর্য', 'তারা', 'গ্রহ', 'নক্ষত্র', 'মহাকাশ', 'আকাশ', 'মেঘ', 'রংধনু', 'বিদ্যুৎ', 'বজ্র', 'মেঘলা', 'রোদ', 'ছায়া', 'আলো', 'অন্ধকার', 'জল', 'স্থল', 'পর্বত', 'পাহাড়', 'টিলা', 'মরুভূমি', 'মাঠ', 'জঙ্গল', 'বন', 'গ্রাম', 'শহর', 'নগর', 'মহানগর', 'রাজধানী', 'দেশ', 'বিদেশ', 'মহাদেশ', 'সমুদ্র', 'নদী', 'খাল', 'বিল', 'হ্রদ', 'পুকুর', 'ডোবা', 'সাগর', 'মহাসাগর', 'প্রান্তর', 'মরুদ্যান', 'সৈকত', 'বালি', 'পাথর', 'নুড়ি', 'কঙ্কর', 'মাটি', 'কাদা', 'ধুলো', 'বালুকরা', 'শিলা', 'গ্রানাইট', 'বেসাল্ট', 'চুনাপাথর', 'বল্ডার', 'পাহাড়ি', 'পর্বতমালা', 'উপত্যকা', 'গিরিখাদ', 'ঝর্ণা', 'প্রপাত', 'জলপ্রপাত', 'ক্যানিয়ন', 'মালভূমি', 'টুন্ড্রা', 'তুন্দ্রা', 'সাভানা', 'গ্রাসল্যান্ড', 'চারণভূমি', 'ম্যানগ্রোভ', 'সুন্দরবন', 'পাতাগাছ', 'চিরসবুজ', 'পর্ণমোচী', 'গুল্ম', 'গুল্মজাতীয়', 'লতা', 'গুল্মলতা', 'বীরুৎ', 'ঘাস', 'শ্যাওলা', 'কাই', 'শৈবাল', 'ফার্ন', 'মস', 'হর্সটেল', 'অর্কিড', 'গোলাপ', 'গাঁদা', 'জবা', 'কৃষ্ণচূড়া', 'রাধাচূড়া', 'কাঞ্চন', 'পলাশ', 'শিমুল', 'শিরীষ', 'কদম', 'নাগেশ্বর', 'চাঁপা', 'বকুল', 'করবী', 'মল্লিকা', 'মালতী', 'যূথিকা', 'রজনীগন্ধা', 'গন্ধরাজ', 'টগর', 'দোলনচাঁপা', 'চামেলী', 'রঙ্গন', 'হাসনাহেনা', 'কাঠগোলাপ', 'নয়নতারা', 'চন্দ্রমল্লিকা', 'সূর্যমুখী', 'গ্লাডিওলাস', 'ডালিয়া', 'বাগানবিলাস', 'চন্দ্রমল্লিকা', 'জিনিয়া', 'পিটুনিয়া', 'মারিগোল্ড', 'ডেইজি', 'লিলি', 'টিউলিপ', 'ড্যাফোডিল', 'হাইসিন্থ', 'ক্রিস্যান্থেমাম', 'পপি', 'ল্যাভেন্ডার', 'আইরিস', 'অ্যাজালিয়া', 'বেগোনিয়া', 'হাইড্রেনজিয়া', 'ফ্লক্স', 'স্ন্যাপড্রাগন', 'প্যানসি', 'ভারবেনা', 'কসমস', 'পেটুনিয়া', 'স্যালভিয়া', 'স্টক', 'ভায়োলা', 'অ্যাস্টার', 'ক্যালেন্ডুলা', 'সেলোসিয়া', 'কোরিওপসিস', 'গেইলার্ডিয়া', 'হোলিহক', 'লুপিন', 'ন্যাস্তারটিয়াম', 'স্ক্যাবিওসা', 'স্ট্রবেরি', 'ব্লুবেরি', 'রাস্পবেরি', 'ব্ল্যাকবেরি', 'ক্র্যানবেরি', 'গোজবেরি', 'ড্রাগনফ্রুট', 'প্যাসনফ্রুট', 'কিউই', 'অ্যাভোকাডো', 'পিচ', 'প্লাম', 'এপ্রিকট', 'নেক্টারিন', 'ল্যাংকাট', 'লংগান', 'রাম্বুটান', 'ম্যাঙ্গোস্টিন', 'পমেলো', 'জাম্বুরা', 'কুমকোয়াত', 'ফিগ', 'অলিভ', 'ডেট', 'প্রুন', 'গ্রেপ', 'কারেন্ট', 'রাইসিন', 'ক্র্যানবেরি', 'ব্ল্যাককারেন্ট', 'রেডকারেন্ট', 'হোয়াইটকারেন্ট', 'গোলাপজাম', 'কদবেল', 'কাঠাল', 'আমলকী', 'হরীতকী', 'বয়ড়া', 'নিম', 'অর্জুন', 'শিশু', 'পাতা', 'ফুল', 'ডাল', 'শাখা', 'কাণ্ড', 'মূল', 'বীজ', 'মাটি', 'পানি', 'বাতাস', 'আগুন', 'ধোঁয়া', 'বরফ', 'বৃষ্টি', 'ঝড়', 'বাদল', 'হিম', 'তুষার', 'কুয়াশা', 'শিশির', 'ঊষা', 'সন্ধ্যা', 'সকাল', 'দুপুর', 'বিকাল', 'রাত', 'ভোর', 'গোধূলি', 'চাঁদ', 'সূর্য', 'তারা', 'গ্রহ', 'নক্ষত্র', 'মহাকাশ', 'আকাশ', 'মেঘ', 'রংধনু', 'বিদ্যুৎ', 'বজ্র', 'মেঘলা', 'রোদ', 'ছায়া', 'আলো', 'অন্ধকার', 'জল', 'স্থল', 'পর্বত', 'পাহাড়', 'টিলা', 'মরুভূমি', 'মাঠ', 'জঙ্গল', 'বন', 'গ্রাম', 'শহর', 'নগর', 'মহানগর', 'রাজধানী', 'দেশ', 'বিদেশ', 'মহাদেশ', 'সমুদ্র', 'নদী', 'খাল', 'বিল', 'হ্রদ', 'পুকুর', 'ডোবা', 'সাগর', 'মহাসাগর', 'প্রান্তর', 'মরুদ্যান', 'সৈকত', 'বালি', 'পাথর', 'নুড়ি', 'কঙ্কর', 'মাটি', 'কাদা', 'ধুলো', 'বালুকরা', 'শিলা', 'গ্রানাইট', 'বেসাল্ট', 'চুনাপাথর', 'বল্ডার', 'পাহাড়ি', 'পর্বতমালা', 'উপত্যকা', 'গিরিখাদ', 'ঝর্ণা', 'প্রপাত', 'জলপ্রপাত', 'ক্যানিয়ন', 'মালভূমি', 'টুন্ড্রা', 'তুন্দ্রা', 'সাভানা', 'গ্রাসল্যান্ড', 'চারণভূমি', 'ম্যানগ্রোভ', 'সুন্দরবন', 'পাতাগাছ', 'চিরসবুজ', 'পর্ণমোচী', 'গুল্ম', 'গুল্মজাতীয়', 'লতা', 'গুল্মলতা', 'বীরুৎ', 'ঘাস', 'শ্যাওলা', 'কাই', 'শৈবাল', 'ফার্ন', 'মস', 'হর্সটেল', 'অর্কিড', 'গোলাপ', 'গাঁদা', 'জবা', 'কৃষ্ণচূড়া', 'রাধাচূড়া', 'কাঞ্চন', 'পলাশ', 'শিমুল', 'শিরীষ', 'কদম', 'নাগেশ্বর', 'চাঁপা', 'বকুল', 'করবী', 'মল্লিকা', 'মালতী', 'যূথিকা', 'রজনীগন্ধা', 'গন্ধরাজ', 'টগর', 'দোলনচাঁপা', 'চামেলী', 'রঙ্গন', 'হাসনাহেনা', 'কাঠগোলাপ', 'নয়নতারা', 'চন্দ্রমল্লিকা', 'সূর্যমুখী', 'গ্লাডিওলাস', 'ডালিয়া', 'বাগানবিলাস', 'চন্দ্রমল্লিকা', 'জিনিয়া', 'পিটুনিয়া', 'মারিগোল্ড', 'ডেইজি', 'লিলি', 'টিউলিপ', 'ড্যাফোডিল', 'হাইসিন্থ', 'ক্রিস্যান্থেমাম', 'পপি', 'ল্যাভেন্ডার', 'আইরিস', 'অ্যাজালিয়া', 'বেগোনিয়া', 'হাইড্রেনজিয়া', 'ফ্লক্স', 'স্ন্যাপড্রাগন', 'প্যানসি', 'ভারবেনা', 'কসমস', 'পেটুনিয়া', 'স্যালভিয়া', 'স্টক', 'ভায়োলা', 'অ্যাস্টার', 'ক্যালেন্ডুলা', 'সেলোসিয়া', 'কোরিওপসিস', 'গেইলার্ডিয়া', 'হোলিহক', 'লুপিন', 'ন্যাস্তারটিয়াম', 'স্ক্যাবিওসা'



];

// Initialize game variables
if (!isset($_SESSION['current_word'])) {
    $_SESSION['current_word'] = '';
}
if (!isset($_SESSION['game_start_time'])) {
    $_SESSION['game_start_time'] = 0;
}
if (!isset($_SESSION['message'])) {
    $_SESSION['message'] = '';
}
if (!isset($_SESSION['time_up'])) {
    $_SESSION['time_up'] = false;
}
if (!isset($_SESSION['payout_message'])) {
    $_SESSION['payout_message'] = '';
}
if (!isset($_SESSION['timer_paused'])) {
    $_SESSION['timer_paused'] = false;
}
if (!isset($_SESSION['game_started'])) {
    $_SESSION['game_started'] = false;
}
if (!isset($_SESSION['time_limit'])) {
    $_SESSION['time_limit'] = 5; // Default 5 seconds
}

// Load permanent score
function loadScore() {
    global $scoreFile;
    if (file_exists($scoreFile)) {
        return (int)file_get_contents($scoreFile);
    }
    return 0;
}

// Save permanent score
function saveScore($score) {
    global $scoreFile;
    file_put_contents($scoreFile, $score);
}

// Initialize score
if (!isset($_SESSION['score'])) {
    $_SESSION['score'] = loadScore();
}

// Process time limit change
if (isset($_POST['set_time'])) {
    $newTime = (int)$_POST['time_limit'];
    if ($newTime > 0) {
        $_SESSION['time_limit'] = $newTime;
        $_SESSION['message'] = "Time limit set to {$_SESSION['time_limit']} seconds";
    } else {
        $_SESSION['message'] = "Time limit must be greater than 0";
    }
}

// Process pause/unpause requests
if (isset($_POST['pause_timer'])) {
    $_SESSION['timer_paused'] = true;
    $_SESSION['pause_time'] = time();
}
if (isset($_POST['unpause_timer'])) {
    if (isset($_SESSION['pause_time'])) {
        // Adjust start time by the pause duration
        $_SESSION['game_start_time'] += (time() - $_SESSION['pause_time']);
        unset($_SESSION['pause_time']);
    }
    $_SESSION['timer_paused'] = false;
}

// Start the game
if (isset($_POST['start_game'])) {
    $_SESSION['game_started'] = true;
    $_SESSION['current_word'] = $wordList[array_rand($wordList)];
    $_SESSION['game_start_time'] = time();
}

// Check if time is up
if ($_SESSION['game_started'] && !$_SESSION['timer_paused']) {
    $elapsedTime = time() - $_SESSION['game_start_time'];
    if ($elapsedTime > $_SESSION['time_limit'] && !empty($_SESSION['current_word']) && !$_SESSION['time_up']) {
        $_SESSION['message'] = "Time's up! The word was '{$_SESSION['current_word']}'";
        $_SESSION['time_up'] = true;
        
        // Start a new round after time is up
        $_SESSION['current_word'] = $wordList[array_rand($wordList)];
        $_SESSION['game_start_time'] = time();
        $_SESSION['time_up'] = false;
    }
}

// Process word submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_word'])) {
        if (!$_SESSION['game_started']) {
            $_SESSION['message'] = "Please start the game first!";
        } else {
            $userWord = strtolower(trim($_POST['user_word']));
            $currentWord = $_SESSION['current_word'];
            $elapsedTime = time() - $_SESSION['game_start_time'];
            
            if ($userWord === $currentWord) {
                if ($elapsedTime <= $_SESSION['time_limit']) {
                    $_SESSION['score']++;
                    saveScore($_SESSION['score']);
                    $_SESSION['message'] = "Correct! +1 point (Time: {$elapsedTime}s)";
                } else {
                    $_SESSION['message'] = "Too slow! You took {$elapsedTime}s (limit: {$_SESSION['time_limit']}s)";
                }
            } else {
                $_SESSION['message'] = "Incorrect! The word was '{$currentWord}'";
            }
            
            // Start a new round after submission
            $_SESSION['current_word'] = $wordList[array_rand($wordList)];
            $_SESSION['game_start_time'] = time();
            $_SESSION['time_up'] = false;
        }
    }
    
    // Process payout request
    if (isset($_POST['payout'])) {
        $payoutAmount = (int)$_POST['payout_amount'];
        
        if ($payoutAmount <= 0) {
            $_SESSION['payout_message'] = "Payout amount must be positive";
        } elseif ($payoutAmount > $_SESSION['score']) {
            $_SESSION['payout_message'] = "You don't have enough points (Current: {$_SESSION['score']})";
        } else {
            $_SESSION['score'] -= $payoutAmount;
            saveScore($_SESSION['score']);
            $_SESSION['payout_message'] = "Success!<br> Paid out {$payoutAmount} point(s)<br>Please wait,<br> the money will be credited to your account within 24 hours.<br>Thank You.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://asikurbd.github.io/wi/grph.png" rel="icon" type="image/x-icon"/>
    <title>Earn Money</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        .word-display {
            font-size: 24px;
            margin: 20px;
            padding: 10px;
            background-color: #f0f0f0;
            border-radius: 5px;
        }
        .timer {
            font-size: 18px;
            color: #666;
        }
        .score {
            font-size: 20px;
            font-weight: bold;
            margin: 10px;
        }
        .message {
            margin: 15px;
            padding: 10px;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .info {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        input[type="text"], input[type="number"] {
            padding: 8px;
            font-size: 16px;
            width: 200px;
            margin: 5px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        button.payout {
            background-color: #007bff;
        }
        button.payout:hover {
            background-color: #0069d9;
        }
        button.start {
            background-color: #ff9800;
        }
        button.start:hover {
            background-color: #e68a00;
        }
        button.settings {
            background-color: #9c27b0;
        }
        button.settings:hover {
            background-color: #7b1fa2;
        }
        .payout-section {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .settings-section {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .paused .timer {
            color: #ff9800;
            font-weight: bold;
        }
        .game-area {
            display: <?php echo $_SESSION['game_started'] ? 'block' : 'none'; ?>;
        }
    </style>
</head>
<body class="<?php echo $_SESSION['timer_paused'] ? 'paused' : ''; ?>">
    <h1>Type Correct Word & Earn Money</h1>
    
    <?php if (!$_SESSION['game_started']): ?>
        <div class="start-section">
            <p>Type the word that appears within the time limit to earn points!</p>
            <p>Your current score: <?php echo $_SESSION['score']; ?></p>
            <form method="post">
                <button type="submit" name="start_game" class="start">Start Game</button>
            </form>
        </div>
    <?php endif; ?>
    
    <div class="game-area">
	Welcome <b>Afsana Sarmin</b> (01517-834602)
        <div class="score">Your Point: <?php echo $_SESSION['score']; ?></div>
		
        
        <?php if (!empty($_SESSION['message'])): ?>
            <div class="message <?php 
                if (strpos($_SESSION['message'], 'Correct') !== false) echo 'success';
                elseif (strpos($_SESSION['message'], 'Time\'s up') !== false) echo 'info';
                else echo 'error';
            ?>">
                <?php echo $_SESSION['message']; ?>
            </div>
        <?php endif; ?>
        
        <div class="word-display"><?php echo $_SESSION['current_word']; ?></div>
        
        <div class="timer" id="timer">
            <?php echo $_SESSION['timer_paused'] ? 'Timer Paused' : "Time left: {$_SESSION['time_limit']}s"; ?>
        </div>
        
        <form method="post" id="wordForm">
            <input type="text" name="user_word" id="user_word" autocomplete="off" <?php echo $_SESSION['timer_paused'] ? '' : 'autofocus'; ?>>
            <button type="submit" name="submit_word">Submit</button>
        </form>
        
        <?php if ($_SESSION['score'] > 0): ?>
        <div class="payout-section">
            <h3>Payout Points</h3>
            <?php if (!empty($_SESSION['payout_message'])): ?>
                <div class="message <?php echo strpos($_SESSION['payout_message'], 'Success') !== false ? 'success' : 'error'; ?>">
                    <?php echo $_SESSION['payout_message']; ?>
                </div>
            <?php endif; ?>
            <form method="post" id="payoutForm">
                <input type="number" name="payout_amount" id="payout_amount" min="1" max="<?php echo $_SESSION['score']; ?>" 
                       value="1" required>
                <button type="submit" name="payout" class="payout">Payout</button>
            </form>
        </div>
        <?php endif; ?>
        
        <div class="settings-section">
       
            <form method="post">
                
                <input type="hidden" name="time_limit" value="7" required>
                <button type="submit" name="set_time" class="settings">Set Time</button>
				<br>
				Current Time: <?php echo $_SESSION['time_limit']; ?> (seconds)
            </form>
			
        </div>
		<a href=""> Refresh</a>
    </div>
    
    <script>
        // Game variables
        const timeLimit = <?php echo $_SESSION['time_limit']; ?>;
        const startTime = <?php echo $_SESSION['game_started'] ? $_SESSION['game_start_time'] : '0'; ?>;
        const timerElement = document.getElementById('timer');
        const wordInput = document.getElementById('user_word');
        const payoutInput = document.getElementById('payout_amount');
        const gameArea = document.querySelector('.game-area');
        let timerPaused = <?php echo $_SESSION['timer_paused'] ? 'true' : 'false'; ?>;
        let remainingTime = timeLimit;
        
        // Timer functionality
        function updateTimer() {
            if (!startTime) return;
            
            if (timerPaused) {
                timerElement.textContent = "Timer Paused";
                timerElement.style.color = "#ff9800";
                return;
            }
            
            const currentTime = Math.floor(Date.now() / 1000);
            const elapsed = currentTime - startTime;
            remainingTime = Math.max(0, timeLimit - elapsed);
            
            timerElement.textContent = `Time left: ${remainingTime}s`;
            
            if (remainingTime <= 0) {
                timerElement.textContent = "Time's up!";
                timerElement.style.color = "red";
                // Auto-refresh to get new word
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            } else {
                setTimeout(updateTimer, 200);
            }
        }
        
        // Pause/unpause functionality
        if (payoutInput) {
            payoutInput.addEventListener('focus', () => {
                if (!timerPaused) {
                    fetch(window.location.href, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'pause_timer=true'
                    }).then(() => {
                        timerPaused = true;
                        document.body.classList.add('paused');
                        updateTimer();
                    });
                }
            });
        }
        
        if (wordInput) {
            wordInput.addEventListener('focus', () => {
                if (timerPaused) {
                    fetch(window.location.href, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'unpause_timer=true'
                    }).then(() => {
                        timerPaused = false;
                        document.body.classList.remove('paused');
                        updateTimer();
                    });
                }
            });
        }
        
        // Initialize timer if game is started
        if (<?php echo $_SESSION['game_started'] ? 'true' : 'false'; ?>) {
            updateTimer();
            
            // Focus the appropriate input field
            if (!timerPaused) {
                wordInput.focus();
            } else if (payoutInput) {
                payoutInput.focus();
            }
        }
    </script>
</body>
</html>
<?php
// Clear messages after displaying them
$_SESSION['message'] = '';
$_SESSION['payout_message'] = '';
?>