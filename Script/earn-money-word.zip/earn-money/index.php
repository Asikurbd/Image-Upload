<?php
session_start();

// File to store scores
$scoreFile = 'scores.txt';

// List of words to match
$wordList = [


'apple', 'banana', 'orange', 'grape', 'mango', 'strawberry', 'blueberry', 'pineapple', 'watermelon', 'kiwi', 'pear', 'peach', 'plum', 'cherry', 'raspberry', 'blackberry', 'lemon', 'lime', 'coconut', 'avocado', 'pomegranate', 'fig', 'guava', 'passionfruit', 'dragonfruit', 'melon', 'apricot', 'nectarine', 'persimmon', 'lychee', 'starfruit', 'tangerine', 'clementine', 'mandarin', 'kumquat', 'boysenberry', 'elderberry', 'cranberry', 'gooseberry', 'mulberry', 'date', 'papaya', 'plantain', 'jackfruit', 'durian', 'breadfruit', 'soursop', 'kiwano', 'quince', 'rhubarb', 'carambola', 'ackee', 'sapodilla', 'salak', 'tamarind', 'ugli', 'yuzu', 'feijoa', 'santol', 'mangosteen', 'longan', 'rambutan', 'custardapple', 'sugarapple', 'sweetsop', 'soursop', 'bilberry', 'cloudberry', 'huckleberry', 'loganberry', 'marionberry', 'olallieberry', 'redcurrant', 'blackcurrant', 'whitecurrant', 'gojiberry', 'juniperberry', 'barberry', 'bearberry', 'chokecherry', 'rowanberry', 'serviceberry', 'buffaloberry', 'hackberry', 'spiceberry', 'wineberry', 'bakeapple', 'bumbleberry', 'caperberry', 'chilepepper', 'eggplant', 'tomato', 'cucumber', 'pumpkin', 'zucchini', 'squash', 'pepper', 'carrot', 'potato', 'onion', 'garlic', 'ginger', 'radish', 'beet', 'celery', 'lettuce', 'spinach', 'kale', 'cabbage', 'broccoli', 'cauliflower', 'asparagus', 'artichoke', 'greenbean', 'pea', 'corn', 'mushroom', 'yam', 'sweetpotato', 'turnip', 'parsnip', 'rutabaga', 'brusselsprout', 'bokchoy', 'arugula', 'endive', 'watercress', 'fennel', 'leek', 'scallion', 'shallot', 'chive', 'okra', 'rhubarb', 'daikon', 'jicama', 'kohlrabi', 'taro', 'yucca', 'plantain', 'nopales', 'alfalfa', 'sprout', 'bean', 'lentil', 'chickpea', 'soybean', 'peanut', 'almond', 'walnut', 'cashew', 'pistachio', 'pecan', 'hazelnut', 'macadamia', 'chestnut', 'pine', 'sunflowerseed', 'pumpkinseed', 'sesameseeds', 'flaxseed', 'chia', 'quinoa', 'barley', 'oats', 'rice', 'wheat', 'rye', 'millet', 'sorghum', 'buckwheat', 'spelt', 'farro', 'amaranth', 'teff', 'bulgur', 'couscous', 'cornmeal', 'polenta', 'semolina', 'tapioca', 'arrowroot', 'soy', 'tofu', 'tempeh', 'seitan', 'edamame', 'miso', 'natto', 'hummus', 'falafel', 'soymilk', 'almondmilk', 'oatmilk', 'ricemilk', 'coconutmilk', 'hempmilk', 'cashewmilk', 'macadamiamilk', 'flaxmilk', 'peamilk', 'horchata', 'chai', 'coffee', 'tea', 'greentea', 'blacktea', 'oolong', 'white', 'herbal', 'rooibos', 'matcha', 'chamomile', 'peppermint', 'hibiscus', 'earlgrey', 'jasmine', 'lavender', 'lemongrass', 'ginger', 'turmeric', 'cinnamon', 'clove', 'nutmeg', 'cardamom', 'allspice', 'vanilla', 'saffron', 'star', 'anise', 'fennel', 'caraway', 'cumin', 'coriander', 'mustard', 'paprika', 'cayenne', 'chili', 'curry', 'garam', 'masala', 'turmeric', 'fenugreek', 'sumac', 'zaatar', 'thyme', 'rosemary', 'sage', 'oregano', 'basil', 'parsley', 'cilantro', 'dill', 'marjoram', 'tarragon', 'bay', 'mint', 'chive', 'lemongrass', 'lavender', 'savory', 'chervil', 'epazote', 'stevia', 'honey', 'maple', 'agave', 'molasses', 'syrup', 'cane', 'brown', 'white', 'powdered', 'coconut', 'palm', 'date', 'corn', 'highfructose', 'artificial', 'aspartame', 'sucralose', 'saccharin', 'xylitol', 'erythritol', 'mannitol', 'sorbitol', 'maltitol', 'lactitol', 'isomalt', 'glycerol', 'hydrogenated', 'starch', 'invert', 'treacle', 'golden', 'blackstrap', 'barley', 'malt', 'rice', 'brownrice', 'wildrice', 'basmati', 'jasmine', 'arborio', 'sushi', 'sticky', 'forbidden', 'red', 'black', 'camargue', 'wehani', 'kalijira', 'matta', 'bhutanese', 'purple', 'glutinous', 'non', 'instant', 'parboiled', 'enriched', 'fortified', 'wholegrain', 'refined', 'bleached', 'unbleached', 'allpurpose', 'bread', 'cake', 'pastry', 'selfrising', 'wholewheat', 'buckwheat', 'coconut', 'almond', 'chickpea', 'rice', 'tapioca', 'potato', 'corn', 'soy', 'quinoa', 'spelt', 'rye', 'oat', 'barley', 'semolina', 'graham', 'matzo', 'durum', 'einkorn', 'emmer', 'farro', 'kamut', 'teff', 'amaranth', 'arrowroot', 'cassava', 'plantain', 'yam', 'sago', 'sorghum', 'millet', 'fonio', 'jobstears', 'kudzu', 'lupin', 'mesquite', 'nopale', 'tigernut', 'waterchestnut', 'acorn', 'chestnut', 'hazelnut', 'almond', 'walnut', 'cashew', 'pistachio', 'pecan', 'macadamia', 'pine', 'brazil', 'peanut', 'coconut', 'sunflower', 'pumpkin', 'sesame', 'flax', 'chia', 'hemp', 'poppy', 'watermelon', 'apricot', 'avocado', 'blackberry', 'blueberry', 'boysenberry', 'cherry', 'cranberry', 'date', 'dragonfruit', 'elderberry', 'fig', 'gooseberry', 'grape', 'grapefruit', 'guava', 'honeydew', 'kiwi', 'lemon', 'lime', 'loganberry', 'longan', 'loquat', 'lychee', 'mandarin', 'mango', 'mulberry', 'nectarine', 'olive', 'orange', 'papaya', 'passionfruit', 'peach', 'pear', 'persimmon', 'pineapple', 'plantain', 'plum', 'pomegranate', 'quince', 'raspberry', 'soursop', 'strawberry', 'tamarind', 'tangerine', 'ugli', 'watermelon', 'yuzu', 'zucchini', 'acai', 'aronia', 'blackcurrant', 'cloudberry', 'crabapple', 'damson', 'feijoa', 'gojiberry', 'jabuticaba', 'jambul', 'jostaberry', 'kiwano', 'lucuma', 'mangosteen', 'marionberry', 'miracle', 'nance', 'pepino', 'pitanga', 'poha', 'pomelo', 'salak', 'santol', 'sapodilla', 'saskatoon', 'serviceberry', 'surinam', 'tayberry', 'thimbleberry', 'wineberry', 'yangmei', 'yumberry', 'ackee', 'breadfruit', 'carambola', 'chayote', 'custardapple', 'durian', 'eggplant', 'jackfruit', 'kohlrabi', 'langsat', 'mamoncillo', 'okra', 'pawpaw', 'rambutan', 'roseapple', 'soursop', 'starfruit', 'sugarapple', 'tamarillo', 'ugli', 'bilimbi', 'cempedak', 'cupuacu', 'gac', 'junglesop', 'kabosu', 'kepel', 'lanzones', 'mamey', 'morus', 'noni', 'pandanus', 'rollinia', 'safou', 'soncoya', 'sweetsop', 'velvet', 'ackee', 'atemoya', 'babaco', 'bignay', 'camucamu', 'charichuelo', 'cocona', 'duku', 'fibrous', 'grumichama', 'imbu', 'june', 'ketembilla', 'lakoocha', 'mabolo', 'maprang', 'marang', 'mundu', 'namnam', 'pacay', 'paniala', 'pulasan', 'pupunha', 'rumberry', 'sampaloc', 'sandoricum', 'sapote', 'screwpine', 'snowberry', 'solanum', 'tomatillo', 'tree', 'wampee', 'whortleberry', 'abiu', 'achacha', 'amla', 'araça', 'bacuri', 'barbados', 'biriba', 'burdekin', 'calabash', 'capulin', 'cattley', 'ceriman', 'chupa', 'corossol', 'curuba', 'damson', 'dewb', 'emblic', 'gamboge', 'genip', 'guanabana', 'harrison', 'icecream', 'illawarra', 'jelly', 'keppel', 'kwai', 'lardizabala', 'lucuma', 'macouga', 'malay', 'matoa', 'maypop', 'medlar', 'melinjo', 'mombin', 'monstera', 'muntries', 'nalca', 'nere', 'orangelo', 'palmyra', 'pequi', 'pitomba', 'poha', 'pommecythere', 'poshte', 'pulasan', 'pummelo', 'quararibea', 'rabutan', 'rimu', 'sageretia', 'satinash', 'seriguela', 'setambun', 'snow', 'soncoya', 'sorb', 'sour', 'suan', 'sweetsop', 'tamarind', 'tangelo', 'ugni', 'velvet', 'wax', 'white', 'wild', 'wongi', 'yellow', 'zapote', 'zigzag', 'ziziphus', 'zucchini', 'abiu', 'acerola', 'akebia', 'alpine', 'amazon', 'amberella', 'ambarella', 'american', 'appleberry', 'apricot', 'arctic', 'australian', 'babaco', 'balsam', 'batuan', 'beach', 'bearberry', 'betel', 'bignay', 'billygoat', 'binjai', 'blackapple', 'blackberry', 'blood', 'blue', 'bolwarra', 'bottle', 'bramble', 'brazilian', 'broadleaf', 'brown', 'buffalo', 'burdekin', 'burmese', 'bush', 'butter', 'caimito', 'calamansi', 'california', 'cambuca', 'canary', 'cantaloupe', 'cape', 'capuli', 'caranda', 'carissa', 'cashew', 'cattley', 'cavendish', 'ceylon', 'charichuelo', 'che', 'cherry', 'chilean', 'chinese', 'chokeberry', 'citron', 'citrus', 'cluster', 'cochin', 'cocoplum', 'coffee', 'colombian', 'common', 'conkerberry', 'cornelian', 'costa', 'crabapple', 'cranberry', 'crimson', 'crowberry', 'cuban', 'cucumber', 'custard', 'dabai', 'davidson', 'deadmans', 'desert', 'douglas', 'dunalia', 'eastern', 'elephant', 'emerald', 'european', 'evergreen', 'farkleberry', 'feijoa', 'fijian', 'finger', 'flame', 'florida', 'forest', 'fragrant', 'fraser', 'fuji', 'galia', 'gambier', 'genip', 'giant', 'goa', 'golden', 'gooseberry', 'goumi', 'granadilla', 'grape', 'great', 'green', 'ground', 'guavaberry', 'hairy', 'hardy', 'hawaiian', 'himalayan', 'honey', 'honeyberry', 'horned', 'hottentot', 'hove', 'hungarian', 'ice', 'illawarra', 'indian', 'indonesian', 'irish', 'italian', 'ivory', 'jaboticaba', 'jamaican', 'japanese', 'java', 'jelly', 'jocote', 'jostaberry', 'jujube', 'jungle', 'kaffir', 'kakadu', 'karanda', 'kei', 'kepel', 'kerr', 'key', 'kiwano', 'kiwi', 'korlan', 'kousa', 'kumquat', 'kwai', 'lady', 'lakoocha', 'langsat', 'laurel', 'lemon', 'lilly', 'lime', 'lingonberry', 'little', 'loganberry', 'longan', 'loquat', 'lucuma', 'lulo', 'lychee', 'madrono', 'malay', 'malaysian', 'mamey', 'mamoncillo', 'mandarin', 'mango', 'mangosteen', 'marang', 'maraschino', 'marula', 'mayapple', 'medlar', 'melinjo', 'melon', 'mexican', 'minneola', 'miracle', 'monkey', 'monstera', 'morinda', 'mountain', 'mulberry', 'muntingia', 'muscadine', 'muskmelon', 'myrtle', 'nagami', 'nance', 'nannyberry', 'natal', 'nectarine', 'negro', 'nere', 'north', 'northern', 'norwegian', 'oil', 'okari', 'orangeberry', 'oregon', 'oriental', 'paddle', 'palm', 'pandanus', 'papaya', 'paradise', 'passionfruit', 'pawpaw', 'peach', 'pear', 'peewah', 'pepino', 'pepper', 'persian', 'persimmon', 'peruvian', 'phalsa', 'pigeon', 'pineapple', 'pitanga', 'pitaya', 'plantain', 'plum', 'poha', 'pomegranate', 'pomelo', 'poshte', 'prairie', 'prickly', 'pulasan', 'pummelo', 'purple', 'quandong', 'queen', 'quince', 'raisin', 'rambutan', 'rangpur', 'raspberry', 'red', 'riberry', 'rimu', 'rose', 'rowan', 'ruby', 'rumberry', 'russian', 'safou', 'sageretia', 'saguaro', 'salal', 'salmonberry', 'sandpaper', 'santol', 'sapodilla', 'sapote', 'saskatoon', 'satsuma', 'sea', 'serviceberry', 'sharon', 'siberian', 'snowberry', 'sorb', 'sour', 'spanish', 'sparkleberry', 'star', 'strawberry', 'sugar', 'sundrop', 'surinam', 'sweet', 'sweetsop', 'tahitian', 'tamarillo', 'tamarind', 'tangelo', 'tangerine', 'tart', 'texas', 'thai', 'thorn', 'tibetan', 'tomatillo', 'tomato', 'toronja', 'tree', 'tropical', 'ugni', 'velvet', 'vietnamese', 'wampee', 'water', 'wax', 'west', 'white', 'wild', 'wineberry', 'winged', 'winter', 'wolfberry', 'wonderberry', 'wood', 'yellow', 'yew', 'yumberry', 'zapote', 'zigzag', 'zinfandel', 'zucchini', 'zulu', 'zygophyllum'



];

// Initialize game variables
if (!isset($_SESSION['current_word'])) {
    $_SESSION['current_word'] = '';
}
if (!isset($_SESSION['game_start_time'])) {
    $_SESSION['game_start_time'] = 0;
}
if (!isset($_SESSION['message'])) {
    $_SESSION['message'] = '';
}
if (!isset($_SESSION['time_up'])) {
    $_SESSION['time_up'] = false;
}
if (!isset($_SESSION['payout_message'])) {
    $_SESSION['payout_message'] = '';
}
if (!isset($_SESSION['timer_paused'])) {
    $_SESSION['timer_paused'] = false;
}
if (!isset($_SESSION['game_started'])) {
    $_SESSION['game_started'] = false;
}
if (!isset($_SESSION['time_limit'])) {
    $_SESSION['time_limit'] = 5; // Default 5 seconds
}

// Load permanent score
function loadScore() {
    global $scoreFile;
    if (file_exists($scoreFile)) {
        return (int)file_get_contents($scoreFile);
    }
    return 0;
}

// Save permanent score
function saveScore($score) {
    global $scoreFile;
    file_put_contents($scoreFile, $score);
}

// Initialize score
if (!isset($_SESSION['score'])) {
    $_SESSION['score'] = loadScore();
}

// Process time limit change
if (isset($_POST['set_time'])) {
    $newTime = (int)$_POST['time_limit'];
    if ($newTime > 0) {
        $_SESSION['time_limit'] = $newTime;
        $_SESSION['message'] = "Time limit set to {$_SESSION['time_limit']} seconds";
    } else {
        $_SESSION['message'] = "Time limit must be greater than 0";
    }
}

// Process pause/unpause requests
if (isset($_POST['pause_timer'])) {
    $_SESSION['timer_paused'] = true;
    $_SESSION['pause_time'] = time();
}
if (isset($_POST['unpause_timer'])) {
    if (isset($_SESSION['pause_time'])) {
        // Adjust start time by the pause duration
        $_SESSION['game_start_time'] += (time() - $_SESSION['pause_time']);
        unset($_SESSION['pause_time']);
    }
    $_SESSION['timer_paused'] = false;
}

// Start the game
if (isset($_POST['start_game'])) {
    $_SESSION['game_started'] = true;
    $_SESSION['current_word'] = $wordList[array_rand($wordList)];
    $_SESSION['game_start_time'] = time();
}

// Check if time is up
if ($_SESSION['game_started'] && !$_SESSION['timer_paused']) {
    $elapsedTime = time() - $_SESSION['game_start_time'];
    if ($elapsedTime > $_SESSION['time_limit'] && !empty($_SESSION['current_word']) && !$_SESSION['time_up']) {
        $_SESSION['message'] = "Time's up! The word was '{$_SESSION['current_word']}'";
        $_SESSION['time_up'] = true;
        
        // Start a new round after time is up
        $_SESSION['current_word'] = $wordList[array_rand($wordList)];
        $_SESSION['game_start_time'] = time();
        $_SESSION['time_up'] = false;
    }
}

// Process word submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_word'])) {
        if (!$_SESSION['game_started']) {
            $_SESSION['message'] = "Please start the game first!";
        } else {
            $userWord = strtolower(trim($_POST['user_word']));
            $currentWord = $_SESSION['current_word'];
            $elapsedTime = time() - $_SESSION['game_start_time'];
            
            if ($userWord === $currentWord) {
                if ($elapsedTime <= $_SESSION['time_limit']) {
                    $_SESSION['score']++;
                    saveScore($_SESSION['score']);
                    $_SESSION['message'] = "Correct! +1 point (Time: {$elapsedTime}s)";
                } else {
                    $_SESSION['message'] = "Too slow! You took {$elapsedTime}s (limit: {$_SESSION['time_limit']}s)";
                }
            } else {
                $_SESSION['message'] = "Incorrect! The word was '{$currentWord}'";
            }
            
            // Start a new round after submission
            $_SESSION['current_word'] = $wordList[array_rand($wordList)];
            $_SESSION['game_start_time'] = time();
            $_SESSION['time_up'] = false;
        }
    }
    
    // Process payout request
    if (isset($_POST['payout'])) {
        $payoutAmount = (int)$_POST['payout_amount'];
        
        if ($payoutAmount <= 0) {
            $_SESSION['payout_message'] = "Payout amount must be positive";
        } elseif ($payoutAmount > $_SESSION['score']) {
            $_SESSION['payout_message'] = "You don't have enough points (Current: {$_SESSION['score']})";
        } else {
            $_SESSION['score'] -= $payoutAmount;
            saveScore($_SESSION['score']);
            $_SESSION['payout_message'] = "Success!<br> Paid out {$payoutAmount} point(s)<br>Please wait,<br> the money will be credited to your account within 24 hours.<br>Thank You.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://asikurbd.github.io/wi/grph.png" rel="icon" type="image/x-icon"/>
    <title>Earn Money</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        .word-display {
            font-size: 24px;
            margin: 20px;
            padding: 10px;
            background-color: #f0f0f0;
            border-radius: 5px;
        }
        .timer {
            font-size: 18px;
            color: #666;
        }
        .score {
            font-size: 20px;
            font-weight: bold;
            margin: 10px;
        }
        .message {
            margin: 15px;
            padding: 10px;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .info {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        input[type="text"], input[type="number"] {
            padding: 8px;
            font-size: 16px;
            width: 200px;
            margin: 5px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        button.payout {
            background-color: #007bff;
        }
        button.payout:hover {
            background-color: #0069d9;
        }
        button.start {
            background-color: #ff9800;
        }
        button.start:hover {
            background-color: #e68a00;
        }
        button.settings {
            background-color: #9c27b0;
        }
        button.settings:hover {
            background-color: #7b1fa2;
        }
        .payout-section {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .settings-section {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .paused .timer {
            color: #ff9800;
            font-weight: bold;
        }
        .game-area {
            display: <?php echo $_SESSION['game_started'] ? 'block' : 'none'; ?>;
        }
    </style>
</head>
<body class="<?php echo $_SESSION['timer_paused'] ? 'paused' : ''; ?>">
    <h1>Type Correct Word & Earn Money</h1>
    
    <?php if (!$_SESSION['game_started']): ?>
        <div class="start-section">
            <p>Type the word that appears within the time limit to earn points!</p>
            <p>Your current score: <?php echo $_SESSION['score']; ?></p>
            <form method="post">
                <button type="submit" name="start_game" class="start">Start Game</button>
            </form>
        </div>
    <?php endif; ?>
    
    <div class="game-area">
	Welcome <b>Afsana Sarmin</b> (01517-834602)
        <div class="score">Your Point: <?php echo $_SESSION['score']; ?></div>
		Start With <a href="bn/index.php">বাংলা</a> Word
		
        
        <?php if (!empty($_SESSION['message'])): ?>
            <div class="message <?php 
                if (strpos($_SESSION['message'], 'Correct') !== false) echo 'success';
                elseif (strpos($_SESSION['message'], 'Time\'s up') !== false) echo 'info';
                else echo 'error';
            ?>">
                <?php echo $_SESSION['message']; ?>
            </div>
        <?php endif; ?>
        
        <div class="word-display"><?php echo $_SESSION['current_word']; ?></div>
        
        <div class="timer" id="timer">
            <?php echo $_SESSION['timer_paused'] ? 'Timer Paused' : "Time left: {$_SESSION['time_limit']}s"; ?>
        </div>
        
        <form method="post" id="wordForm">
            <input type="text" name="user_word" id="user_word" autocomplete="off" <?php echo $_SESSION['timer_paused'] ? '' : 'autofocus'; ?>>
            <button type="submit" name="submit_word">Submit</button>
        </form>
        
        <?php if ($_SESSION['score'] > 0): ?>
        <div class="payout-section">
            <h3>Payout Points</h3>
            <?php if (!empty($_SESSION['payout_message'])): ?>
                <div class="message <?php echo strpos($_SESSION['payout_message'], 'Success') !== false ? 'success' : 'error'; ?>">
                    <?php echo $_SESSION['payout_message']; ?>
                </div>
            <?php endif; ?>
            <form method="post" id="payoutForm">
                <input type="number" name="payout_amount" id="payout_amount" min="1" max="<?php echo $_SESSION['score']; ?>" 
                       value="1" required>
                <button type="submit" name="payout" class="payout">Payout</button>
            </form>
        </div>
        <?php endif; ?>
        
        <div class="settings-section">
       
            <form method="post">
                
                <input type="hidden" name="time_limit" value="7" required>
                <button type="submit" name="set_time" class="settings">Set Time</button>
				<br>
				Current Time: <?php echo $_SESSION['time_limit']; ?> (seconds)
            </form>
			
        </div>
		<a href=""> Refresh</a>
    </div>
    
    <script>
        // Game variables
        const timeLimit = <?php echo $_SESSION['time_limit']; ?>;
        const startTime = <?php echo $_SESSION['game_started'] ? $_SESSION['game_start_time'] : '0'; ?>;
        const timerElement = document.getElementById('timer');
        const wordInput = document.getElementById('user_word');
        const payoutInput = document.getElementById('payout_amount');
        const gameArea = document.querySelector('.game-area');
        let timerPaused = <?php echo $_SESSION['timer_paused'] ? 'true' : 'false'; ?>;
        let remainingTime = timeLimit;
        
        // Timer functionality
        function updateTimer() {
            if (!startTime) return;
            
            if (timerPaused) {
                timerElement.textContent = "Timer Paused";
                timerElement.style.color = "#ff9800";
                return;
            }
            
            const currentTime = Math.floor(Date.now() / 1000);
            const elapsed = currentTime - startTime;
            remainingTime = Math.max(0, timeLimit - elapsed);
            
            timerElement.textContent = `Time left: ${remainingTime}s`;
            
            if (remainingTime <= 0) {
                timerElement.textContent = "Time's up!";
                timerElement.style.color = "red";
                // Auto-refresh to get new word
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            } else {
                setTimeout(updateTimer, 200);
            }
        }
        
        // Pause/unpause functionality
        if (payoutInput) {
            payoutInput.addEventListener('focus', () => {
                if (!timerPaused) {
                    fetch(window.location.href, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'pause_timer=true'
                    }).then(() => {
                        timerPaused = true;
                        document.body.classList.add('paused');
                        updateTimer();
                    });
                }
            });
        }
        
        if (wordInput) {
            wordInput.addEventListener('focus', () => {
                if (timerPaused) {
                    fetch(window.location.href, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'unpause_timer=true'
                    }).then(() => {
                        timerPaused = false;
                        document.body.classList.remove('paused');
                        updateTimer();
                    });
                }
            });
        }
        
        // Initialize timer if game is started
        if (<?php echo $_SESSION['game_started'] ? 'true' : 'false'; ?>) {
            updateTimer();
            
            // Focus the appropriate input field
            if (!timerPaused) {
                wordInput.focus();
            } else if (payoutInput) {
                payoutInput.focus();
            }
        }
    </script>
</body>
</html>
<?php
// Clear messages after displaying them
$_SESSION['message'] = '';
$_SESSION['payout_message'] = '';
?>